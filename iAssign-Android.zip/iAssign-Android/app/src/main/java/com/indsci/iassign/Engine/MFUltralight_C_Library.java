package com.indsci.iassign.Engine;

import android.content.Context;

import com.indsci.iassign.Common.NdefRecord_Util;
import com.indsci.iassign.Common.iError;
import com.indsci.iassign.R;
import com.nxp.nfclib.exceptions.ReaderException;
import com.nxp.nfclib.exceptions.SmartCardException;
import com.nxp.nfclib.ndef.NdefMessageWrapper;
import com.nxp.nfclib.ultralight.IUltralightC;
import java.io.IOException;
import java.util.Locale;

public class MFUltralight_C_Library {

    /** Mifare Ultralight instance initiated. */
    private IUltralightC objUlCardC;

    /** Application Tag. */
    static final String TAG = "iAssign";

    private Context context;

    /** Hardware key store check. */
    private boolean isHardwareKeystore = false;

    /** byte array. */
    byte[] data;

    public MFUltralight_C_Library()
    {

    }

    public MFUltralight_C_Library(IUltralightC obj , Context _context)
    {
        objUlCardC = obj;
        context = _context;
    }

    public iError MFUltralight_C_Connect()
    {
        try {
            objUlCardC.getReader().connect();
            return new iError(true, context.getString(R.string.connected));
        }
        catch (ReaderException casue)
        {
            casue.printStackTrace();
            return new iError(false, context.getString(R.string.connection_failed));
        }
    }

    /**
     * MIFARE Ultralight-C Card Logic.
     */
    public iError Write_NDEF_Record(String data, boolean lock_tag)
    {
        try
        {
            boolean is_already_connected = objUlCardC.getReader().isConnected();


            // Connect Card
            objUlCardC.getReader().connect();

            // Let's format card always.
            // Format card for Forum Type 2.
            if(!objUlCardC.isT2T()) {
                objUlCardC.formatT2T();
            }


            NdefMessageWrapper msg = new NdefMessageWrapper(NdefRecord_Util.createTextRecord(data,
                    Locale.ENGLISH, true));

            // Write NDEF Message
            objUlCardC.writeNDEF(msg);

            if(lock_tag)
            {
                objUlCardC.makeCardReadOnly();
            }

            // Close connection
            objUlCardC.getReader().close();
        }
        catch (SmartCardException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }
        catch (ReaderException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }
        catch (IOException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }

        return new iError(true , context.getString(R.string.write_successful));
    }
}
