package com.indsci.iassign.Common;

public enum TagType
{
    MiFareUltraLightC,
    NTag203x,
    NTag213215216,
    NTAG_I2C,
    NTAG_I2C_Plus,
    Unknown
}
