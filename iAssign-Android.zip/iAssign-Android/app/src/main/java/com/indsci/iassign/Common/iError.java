package com.indsci.iassign.Common;

public class iError {
    boolean status;
    String message;

    public static final String App_TAG = "iAssign";

    public iError()
    {

    }

    public iError(boolean _status, String _msg)
    {
        status = _status;
        message = _msg;
    }

    public void setStatus(boolean _status)
    {
        status = _status;
    }

    public boolean getStatus()
    {
        return status;
    }

    public void setMessage(String msg)
    {
        message = msg;
    }

    public String getMessage()
    {
        return  message;
    }

}
