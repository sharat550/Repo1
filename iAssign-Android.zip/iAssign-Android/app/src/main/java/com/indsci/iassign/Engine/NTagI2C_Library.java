package com.indsci.iassign.Engine;

import android.content.Context;
import android.nfc.Tag;
import android.nfc.tech.NfcA;

import com.indsci.iassign.Common.NdefRecord_Util;
import com.indsci.iassign.Common.iError;
import com.indsci.iassign.R;
import com.nxp.nfclib.exceptions.ReaderException;
import com.nxp.nfclib.exceptions.SmartCardException;
import com.nxp.nfclib.ndef.NdefMessageWrapper;
import com.nxp.nfclib.ntag.INTagI2C;

import java.io.IOException;
import java.util.Locale;

public class NTagI2C_Library
{
    INTagI2C objNtagI2C;
    Context context;

    /**
     * Application Tag.
     */
    static final String TAG = "iAssign";

    public NTagI2C_Library() {
        // Empty constructor
    }

    public NTagI2C_Library(INTagI2C obj, Context _context) {
        objNtagI2C = obj;
        context = _context;
    }

    public iError Write_NDEF_Record(String data, boolean lock_tag) {
        try
        {
            objNtagI2C.getReader().connect();

            if (!objNtagI2C.isT2T()) {
                // Format card for Forum Type 2.
                objNtagI2C.formatT2T();
            }

            NdefMessageWrapper msg = new NdefMessageWrapper(NdefRecord_Util.createTextRecord(data,
                        Locale.ENGLISH, true));

            // Write NDEF Message to target
            objNtagI2C.writeNDEF(msg);

            // Close connection
            objNtagI2C.getReader().close();
        }
        catch (ReaderException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }
        catch (SmartCardException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        } catch (IOException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }

        return new iError(true, context.getString(R.string.write_successful));
    }

    public iError lockTag() {
        try {
            objNtagI2C.getReader().connect();

            /* Check if serial mem page is locked. If null (not present) or page is locked,
            this is a beacon and lock should NOT be performed. */
            Boolean beaconCheck = objNtagI2C.isPageLocked(197);
            if (beaconCheck != null) {
                if (!beaconCheck) {
                    objNtagI2C.makeCardReadOnly();
                }

            }

            objNtagI2C.getReader().close();
        } catch (Exception e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }

        return new iError(true, context.getString(R.string.write_successful));
    }



    public boolean lockBeacon(byte[] hashedPass) {

        try {
            // Open connection
            objNtagI2C.getReader().connect();

            byte[] lockTransmission = new byte[] { (byte)0xAB, (byte)0xAB, (byte)0xAB, (byte)0xAB};

            objNtagI2C.write(224, lockTransmission);
            objNtagI2C.write(225, hashedPass);

            // Close connection
            objNtagI2C.getReader().close();

        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;


    }

    public iError unlockBeacon() {

        try {
            byte[] unlockTransmission = new byte[] { (byte)0xBA, (byte)0xBA, (byte)0xBA, (byte)0xBA};
            byte[] fillerTransmission = new byte[] { (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00 };

            objNtagI2C.write(224,unlockTransmission);
            objNtagI2C.write(225, fillerTransmission);

        }
        catch (Exception e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }
        return new iError(true, context.getString(R.string.write_successful));


    }


}
