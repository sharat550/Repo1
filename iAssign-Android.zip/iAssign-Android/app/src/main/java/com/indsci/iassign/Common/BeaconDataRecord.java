package com.indsci.iassign.Common;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by JAgostoni on 7/11/2016.
 */
public class BeaconDataRecord implements NDefDataRecord {
    String Site;
    String Access;
    String Range;
    String Mode;
    Boolean IsLocked;

    public String getAccess() {
        return Access;
    }

    public String getMode() {
        return Mode;
    }

    public String getRange() {
        return Range;
    }

    public String getSite() {
        return Site;
    }

    public Boolean getLocked() {
        return IsLocked;
    }

    public void setAccess(String access) {
        Access = access;
    }

    public void setMode(String mode) {
        Mode = mode;
    }

    public void setRange(String range) {
        Range = range;
    }

    public void setSite(String site) {
        Site = site;
    }

    public void setLocked(Boolean locked) {
        IsLocked = locked;
    }

    public static BeaconDataRecord FromNDefFields(String data, boolean is_locked) {
        List<String> fields = Arrays.asList(data.split("#"));

        return FromNDefFields(fields, is_locked);

    }
    public static BeaconDataRecord FromNDefFields(List<String> fields, boolean is_locked) {
        BeaconDataRecord record = new BeaconDataRecord();

        record.setLocked(is_locked);


        // TODO: try/catch for format issues

        try {
            for (String field : fields) {
                String[] kvp = field.split(":");
                switch (kvp[0]) {
                    case "Site":
                        record.setSite(kvp[1]);
                        break;
                    case "Access":
                        record.setAccess(kvp[1]);
                        break;
                    case "Range":
                        record.setRange(kvp[1]);
                        break;
                    case "Mode":
                        record.setMode(kvp[1]);
                        break;
                }
            }
        } catch(Exception e) {
            return null;
        }
        return record;

    }

    public String toNDefString() {
        List<String> fields = new ArrayList<String>(4);

        fields.add("Site:" + Site);
        fields.add("Access:" + Access);
        fields.add("Range:" + Range);
        fields.add("Mode:" + Mode);

        String ndefResult = TextUtils.join("#", fields) + "#";

        for (int i = 0; i < (16 - Site.length()); i++) {
            ndefResult = ndefResult + (char)0x00;
        }

        return ndefResult;

    }
}
