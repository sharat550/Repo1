package com.indsci.iassign.Beacons;


import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import com.indsci.iassign.Common.FrameNames;
import com.indsci.iassign.Common.NextAction;
import com.indsci.iassign.HomeActivity;
import com.indsci.iassign.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class BeaconHomePageFragment extends Fragment {

    private LinearLayout _WriteBeaconButton;
    private LinearLayout _ReadBeaconButton;
    private LinearLayout _BeaconModeButton;

    public Dialog read_dialog;

    public static BeaconHomePageFragment newInstance() {
        
        Bundle args = new Bundle();
        
        BeaconHomePageFragment fragment = new BeaconHomePageFragment();
        fragment.setArguments(args);
        return fragment;
    } 

    public BeaconHomePageFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_beacon_home_page, container, false);


        _WriteBeaconButton = (LinearLayout) inflated.findViewById(R.id.btn_beacon_configure);
        _WriteBeaconButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HomeActivity.PushFragment(getFragmentManager(), BeaconWriteFragment.newInstance(), FrameNames.beacon_write_page_fragment_string);
            }
        });


        _ReadBeaconButton = (LinearLayout) inflated.findViewById(R.id.btn_beacon_read);
        _ReadBeaconButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!get_NFC_state())
                {
                    display_error_message(getString(R.string.nfc_disabled), NextAction.Enable_NFC);
                }
                else {
                    display_read_beacon_dialog(view);
                }
            }
        });

        _BeaconModeButton = (LinearLayout) inflated.findViewById(R.id.btn_beacon_mode);
        _BeaconModeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!get_NFC_state()) {
                    display_error_message(getString(R.string.nfc_disabled), NextAction.Enable_NFC);
                }
                else {
                    HomeActivity hActivity = (HomeActivity) getActivity();
                    hActivity.Mode_Read_Flag = true;
                    display_read_beacon_dialog(view);
                }
            }
        });



        return inflated;
    }

    @Override
    public void onStop ()
    {
        super.onStop();

        if(read_dialog != null) {
            if (read_dialog.isShowing()) {
                read_dialog.dismiss();
            }
        }
    }


    private boolean get_NFC_state()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            return hActivity.getNFC_state();
        }

        return false;
    }

    private void display_error_message(String msg, NextAction _next)
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.display_error_dialog(msg, _next, false);
        }
    }

    private void display_read_beacon_dialog(View v)
    {
        read_dialog = new Dialog(getActivity());

        // Include dialog.xml file
        read_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        read_dialog.setContentView(R.layout.readbeacon_dialog);
        read_dialog.show();

        WindowManager.LayoutParams lp = read_dialog.getWindow().getAttributes();
        lp.dimAmount = 0.8f;
        read_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        read_dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

    }

    public void dismiss_read_beacon_dialog() {
        if (read_dialog != null) {
            read_dialog.dismiss();
        }
        read_dialog = null;

    }

}
