package com.indsci.iassign.Beacons;


import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import android.widget.*;
import com.indsci.iassign.Common.*;
import com.indsci.iassign.HomeActivity;
import com.indsci.iassign.R;

import java.util.ArrayList;

public class BeaconWriteFragment extends Fragment {

    public static final String BEACON_DATA_RECORD_ARG = "com.isc.iassign.beaconrecord";

    private EditText _Site;
    private TextView _SiteCount;

    private Spinner _RangeLevel;
    private ArrayAdapter<String> _rangeAdapter;
    private ArrayList<String> _rangeValues;

    private Spinner _AccessLevel;
    private ArrayAdapter<String> _accessAdapter;
    private ArrayList<String> _accessValues;

    private Button _WriteButton;

    private CheckBox _Locked;

    private String _PIN;

    private PinEntryDialogFragment entryFragment;

    private HomeActivity _Home;

    private String blockCharacterSet = ":#";

    private InputFilter characterfilter = new InputFilter() {

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

            if (source != null && blockCharacterSet.contains(("" + source))) {
                return "";
            }
            return null;
        }
    };



    public BeaconWriteFragment() {
        // Required empty public constructor
    }


    public static BeaconWriteFragment newInstance() {
        
        Bundle args = new Bundle();
        
        BeaconWriteFragment fragment = new BeaconWriteFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static BeaconWriteFragment newInstance(BeaconDataRecord data) {
        Bundle args = new Bundle();

        args.putString(BEACON_DATA_RECORD_ARG, data.toNDefString());

        BeaconWriteFragment fragment = new BeaconWriteFragment();
        fragment.setArguments(args);
        return fragment;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        _Home = (HomeActivity) getActivity();
        _Home.Mode_Write_Flag = false;

        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_beacon_write, container, false);

        _RangeLevel = (Spinner) inflated.findViewById(R.id.beacon_range_level);
        _rangeValues = RangeLevel.toIdList();
        _rangeAdapter = new ArrayAdapter<>(inflated.getContext(), android.R.layout.simple_list_item_1, _rangeValues);
        _RangeLevel.setAdapter(_rangeAdapter);

        _AccessLevel = (Spinner) inflated.findViewById(R.id.beacon_access_level);
        _accessValues = BeaconAccessLevel.toIdList();
        _accessAdapter = new ArrayAdapter<>(inflated.getContext(), android.R.layout.simple_list_item_1, _accessValues);
        _AccessLevel.setAdapter(_accessAdapter);

        _SiteCount = (TextView) inflated.findViewById(R.id.write_beacon_site_char_count);
        _Site = (EditText) inflated.findViewById(R.id.editbox_writebeacon_site);
        _Site.addTextChangedListener(new TextCountWatcher(_SiteCount, 16));
        _Site.setFilters(new InputFilter[]{characterfilter, new InputFilter.LengthFilter(16)});

        _Locked = (CheckBox) inflated.findViewById(R.id.beacon_cbox_locktag);
        _Locked.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(final CompoundButton compoundButton, boolean b) {
                if(b) {
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    Fragment prev = getFragmentManager().findFragmentByTag(FrameNames.beacon_pin_entry_fragment_string);
                    if (prev != null) {
                        ft.remove(prev);
                    }
                    ft.addToBackStack(FrameNames.beacon_pin_entry_fragment_string);

                        // Create and show the dialog.
                        entryFragment = PinEntryDialogFragment.newInstance();
                        entryFragment.setOnPINEntryListener(new PinEntryDialogFragment.PINEntryListener() {
                            @Override
                            public void pinEntryCanceled() {
                                compoundButton.setChecked(false);
                                _PIN = "";
                            }

                            @Override
                            public void pinEntryCompleted(String pinValue) {
                                _PIN = pinValue;
                                compoundButton.setChecked(true);
                                _Home.mLockPIN = pinValue;

                            }
                        });
                        ft.addToBackStack(null);
                        entryFragment.show(ft, FrameNames.beacon_pin_entry_fragment_string);

                    }



                }

        });




        _WriteButton = (Button) inflated.findViewById(R.id.beacon_write_button);
        _WriteButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    view.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                } else if(motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    view.setBackground(getResources().getDrawable(R.drawable.button_back));

                    SubmitData();

                }

                return true;
            }
        });




        reloadData(this.getArguments());



        return inflated;
    }

    @Override
    public void onPause() {
        _Locked.setChecked(false);
        if (entryFragment != null) {
            entryFragment.dismiss();
            entryFragment = null;
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        if (_Home != null) {
            _Home.dismiss_writing_dialog();
            _Home.Ready_To_Write_Flag = false;
        }

        super.onDestroy();
    }


    private void SubmitData() {
        Boolean locked = _Locked.isChecked();
        String site = _Site.getText().toString();


        String range;
        RangeLevel rl = RangeLevel.fromString(_RangeLevel.getSelectedItem().toString());
        // rl found in the enum, use this value
        if (rl != null) {
            range = rl.toValue();
        }
        // not found in the enum, submit raw data for write to beacon
        else {
            range = _RangeLevel.getSelectedItem().toString();
        }


        String accessLevel;
        BeaconAccessLevel al = BeaconAccessLevel.fromString(_AccessLevel.getSelectedItem().toString());
        // al found in the enum, use this value
        if (al != null) {
            accessLevel = al.toValue();
        }
        // not found in the enum, submit raw data for write to beacon
        else {
            accessLevel = _AccessLevel.getSelectedItem().toString();
        }


        // Always write the beacon mode as Normal in this interaction
        String mode = BeaconMode.Normal.toValue();


        // Validation
        if(!_Home.getNFC_state()) {
            _Home.display_error_dialog(getString(R.string.nfc_disabled), NextAction.Enable_NFC, true);
            return;
        }

        if(site.equals("")) {
            _Home.display_error_dialog(getString(R.string.beacon_site_required_message), NextAction.Unknown, false);
            return;
        }

        // Trigger a write
        BeaconDataRecord record = new BeaconDataRecord();
        record.setAccess(accessLevel);
        record.setRange(range);
        record.setSite(site);
        record.setMode(mode);

        _Home.Ready_To_Write_Flag = true;
        _Home.display_writing_beacon_dialog(record, locked);
    }


    private void reloadData(Bundle savedState) {
        if(savedState != null) {
            String data = savedState.getString(BEACON_DATA_RECORD_ARG);
            if (data != null) {
                BeaconDataRecord record = BeaconDataRecord.FromNDefFields(data, false); // TODO - Encode locked?
                if (record != null) {


                    if (_Site != null) {
                        _Site.setText(record.getSite());
                    }


                    if(_RangeLevel != null) {
                        RangeLevel l = RangeLevel.fromValue(record.getRange());
                        if(l != null)
                        {
                            _RangeLevel.setSelection(_rangeAdapter.getPosition(l.toString()));
                        }
                        else {
                            _rangeAdapter.add(record.getRange());
                            _rangeAdapter.notifyDataSetChanged();
                            _RangeLevel.setSelection(_rangeAdapter.getPosition(record.getRange()));
                        }
                    }


                    if(_AccessLevel != null) {
                        BeaconAccessLevel a = BeaconAccessLevel.fromValue(record.getAccess());
                        if(a != null) {
                            _AccessLevel.setSelection(_accessAdapter.getPosition(a.toString()));
                        }
                        else {
                            _accessAdapter.add(record.getAccess());
                            _accessAdapter.notifyDataSetChanged();
                            _AccessLevel.setSelection(_accessAdapter.getPosition(record.getAccess()));
                        }
                    }
                }
            }
        }
    }

}
