package com.indsci.iassign.Engine;

import android.content.Context;
import com.indsci.iassign.Common.NdefRecord_Util;
import com.indsci.iassign.Common.iError;
import com.indsci.iassign.R;
import com.nxp.nfclib.exceptions.ReaderException;
import com.nxp.nfclib.exceptions.SmartCardException;
import com.nxp.nfclib.ndef.NdefMessageWrapper;
import com.nxp.nfclib.ntag.INTag203x;
import java.io.IOException;
import java.util.Locale;

public class NTag203x_Library
{
    INTag203x objNtag203x;

    Context context;

    /**
     * Application Tag.
     */
    static final String TAG = "iAssign";

    public NTag203x_Library() {

    }

    public NTag203x_Library(INTag203x obj, Context _context) {
        objNtag203x = obj;
        context = _context;
    }

    public iError NTag203x_Connect() {
        try
        {
            objNtag203x.getReader().connect();
            return new iError(true, context.getString(R.string.connected));
        } catch (ReaderException cause) {
            return new iError(false, context.getString(R.string.connection_failed));
        }
    }

    public iError Write_NDEF_Record(String data, boolean lock_tag) {
        try
        {
            objNtag203x.getReader().connect();


            if (!objNtag203x.isT2T()) {
                // Format card for Forum Type 2.
                objNtag203x.formatT2T();
            }

            NdefMessageWrapper msg = new NdefMessageWrapper(NdefRecord_Util.createTextRecord(data,
                    Locale.ENGLISH, true));

            // Write NDEF Message
            objNtag203x.writeNDEF(msg);

            if(lock_tag)
            {
                objNtag203x.makeCardReadOnly();
            }

            // Close connection
            objNtag203x.getReader().close();
        }
        catch (ReaderException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }
        catch (SmartCardException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        } catch (IOException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }

        return new iError(true, context.getString(R.string.write_successful));
    }
}
