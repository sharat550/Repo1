package com.indsci.iassign.Engine;

import android.content.Context;
import com.indsci.iassign.Common.NdefRecord_Util;
import com.indsci.iassign.Common.iError;
import com.indsci.iassign.R;
import com.nxp.nfclib.exceptions.ReaderException;
import com.nxp.nfclib.exceptions.SmartCardException;
import com.nxp.nfclib.ndef.NdefMessageWrapper;
import com.nxp.nfclib.ntag.INTAGI2Cplus;

import java.io.IOException;
import java.util.Locale;

public class NTagI2CPlus_Library {
    INTAGI2Cplus objNtagI2CPlus;

    Context context;

    /**
     * Application Tag.
     */
    static final String TAG = "iAssign";

    public NTagI2CPlus_Library() {

    }

    public NTagI2CPlus_Library(INTAGI2Cplus obj, Context _context) {
        objNtagI2CPlus = obj;
        context = _context;
    }

    public iError Write_NDEF_Record(String data, boolean lock_tag) {
        try
        {
            objNtagI2CPlus.getReader().connect();


            if (!objNtagI2CPlus.isT2T()) {
                // Format card for Forum Type 2.
                objNtagI2CPlus.formatT2T();
            }

            NdefMessageWrapper msg = new NdefMessageWrapper(NdefRecord_Util.createTextRecord(data,
                    Locale.ENGLISH, true));

            // Write NDEF Message
            objNtagI2CPlus.writeNDEF(msg);

            if(lock_tag)
            {
                objNtagI2CPlus.makeCardReadOnly();
            }

            // Close connection
            objNtagI2CPlus.getReader().close();
        }
        catch (ReaderException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }
        catch (SmartCardException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        } catch (IOException e) {
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }

        return new iError(true, context.getString(R.string.write_successful));
    }
}
