package com.indsci.iassign.Beacons;


import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.indsci.iassign.Common.BeaconDataRecord;
import com.indsci.iassign.Common.BeaconMode;
import com.indsci.iassign.Common.NextAction;
import com.indsci.iassign.HomeActivity;
import com.indsci.iassign.R;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class BeaconModeFragment extends Fragment {

    public static final String BEACON_DATA_RECORD_ARG = "com.isc.iassign.beaconrecord";

    private Button _WriteButton;

    private HomeActivity _Home;

    private TextView _currentModeText;
    private Spinner _newModeSpinner;
    private ArrayAdapter<String> _modeSpinnerAdapter;
    private ArrayList<String> _modeValues;

    private BeaconDataRecord _beaconRecord;


    public BeaconModeFragment() {
        // Required empty public constructor
    }


    public static BeaconModeFragment newInstance(BeaconDataRecord data) {
        Bundle args = new Bundle();

        args.putString(BEACON_DATA_RECORD_ARG, data.toNDefString());

        BeaconModeFragment fragment = new BeaconModeFragment();
        fragment.setArguments(args);
        return fragment;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        _Home = (HomeActivity) getActivity();
        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_beacon_mode, container, false);

        _currentModeText = (TextView) inflated.findViewById(R.id.current_mode_entry);

        _newModeSpinner = (Spinner) inflated.findViewById(R.id.new_mode_spinner);
        _modeValues = BeaconMode.toIdList();
        _modeSpinnerAdapter = new ArrayAdapter<String>(inflated.getContext(), android.R.layout.simple_list_item_1, _modeValues);
        _newModeSpinner.setAdapter(_modeSpinnerAdapter);

        _WriteButton = (Button) inflated.findViewById(R.id.beacon_write_button);
        _WriteButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if(motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    view.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                } else if(motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    view.setBackground(getResources().getDrawable(R.drawable.button_back));

                    SubmitData();

                }

                return true;
            }
        });



        reloadData(this.getArguments());

        return inflated;
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    /**
     * Triggers a write to a beacon given selected items.
     */
    private void SubmitData() {

        // Validate that NFC is enabled. If not, display an error
        if(!_Home.getNFC_state()) {
            _Home.display_error_dialog(getString(R.string.nfc_disabled), NextAction.Enable_NFC, false);
            return;
        }

        // Get selected value from mode spinner
        BeaconMode bm = BeaconMode.fromString(_newModeSpinner.getSelectedItem().toString());
        if (bm != null) {
            _beaconRecord.setMode(bm.toValue());
        }
        // bm is null, meaning that the value is not in the enum. Set mode to raw value.
        else {
            _beaconRecord.setMode(_newModeSpinner.getSelectedItem().toString());
        }

        // Set write flag, display write dialog
        _Home.Ready_To_Write_Flag = true;
        _Home.Mode_Write_Flag = true;
        _Home.display_writing_beacon_dialog(_beaconRecord, false, true);
    }

    /**
     * Loads or reloads field data upon instantiation or change of device orientation.
     * @param savedState The bundle containing saved state information.
     */
    private void reloadData(Bundle savedState) {
        if(savedState != null) {
            String data = savedState.getString(BEACON_DATA_RECORD_ARG);
            if (data != null) {

               _beaconRecord = BeaconDataRecord.FromNDefFields(data, false);

                if (_beaconRecord != null) {
                    BeaconMode bm = BeaconMode.fromValue(_beaconRecord.getMode());
                    //Unable to find matching value, add it to the spinner
                    if (bm == null) {
                        _modeSpinnerAdapter.add(_beaconRecord.getMode());
                        _modeSpinnerAdapter.notifyDataSetChanged();
                        _newModeSpinner.setSelection(BeaconMode.values().length);
                        _currentModeText.setText(_beaconRecord.getMode());
                    }
                    // Matching value found
                    else {
                        _currentModeText.setText(bm.toString());
                    }



                }
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        if (_Home != null) {
            _Home.dismiss_writing_dialog();
            _Home.Mode_Write_Flag = false;
            _Home.Ready_To_Write_Flag = false;
        }

        super.onDestroy();
    }



}
