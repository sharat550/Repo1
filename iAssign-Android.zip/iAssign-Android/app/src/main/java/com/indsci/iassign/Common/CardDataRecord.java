package com.indsci.iassign.Common;

/**
 * Created by Mike Kloszewski on 8/19/2016.
 * Represents a complete record of the data on a wireless activation card.
 */
public class CardDataRecord implements NDefDataRecord {
    private int CardType;
    private int UnlockCount;
    private int SavedSerialCount;
    private String[] ActivatedSerials;


    /**
     * Public constructor for instance of CardDataRecord.
     * Takes a raw NDEF payload and creates the object from the values present.
     * @param ndefPayload The NDEF payload read from the card.
     */
    public CardDataRecord(String ndefPayload) {
        String[] fields = ndefPayload.split("#|:");

        char[] typeBuffer = fields[1].toCharArray();
        CardType = (byte)typeBuffer[0];

        char[] unlockCtBuffer = fields[2].toCharArray();
        UnlockCount = (byte)unlockCtBuffer[0];

        char[] serialCtBuffer = fields[4].toCharArray();
        SavedSerialCount = (byte)serialCtBuffer[0];

        ActivatedSerials = new String[fields.length-5];
        System.arraycopy(fields, 5, ActivatedSerials, 0, fields.length - 5 );

    }

    /**
     * Default constructor. Used by card fragment on device rotation.
     */
    public CardDataRecord() {
        // Empty default constructor
    }


    // Will not be used, as cards are read-only
    @Override
    public String toNDefString() {
        throw new UnsupportedOperationException();
    }


    // Getter and setter methods
    public int getCardType() { return CardType; }

    public void setCardType(int type) { CardType = type; }

    public int getUnlockCount() { return UnlockCount; }

    public void setUnlockCount(int count) { UnlockCount = count; }

    public int getSavedSerialCount() { return SavedSerialCount; }

    public void setSavedSerialCount(int count) { SavedSerialCount = count; }

    public String[] getActivatedSerials() { return ActivatedSerials; }

    public void setActivatedSerials(String[] serials) { ActivatedSerials = serials; }

}
