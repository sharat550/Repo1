package com.indsci.iassign;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.indsci.iassign.Common.TagDataRecord;
import com.indsci.iassign.Common.NextAction;
import com.indsci.iassign.Common.iError;

import java.util.List;

public class BulkWriteFragment extends Fragment
{
    private static final String Bulk = "BulkString";
    private static final String Write = "isWrite";

    private static final int Failed = 0;
    private static final int Passed = 1;
    private static final int New = 2;

    /* List view that holds bulk write data*/
    private ListView mListView;

    /* Bulk write button instance that starts write operation*/
    private Button btnBulkWrite;

    /* Clear button instance that clears currently list view data.*/
    private Button btnClear;

    /* Text view that displays message "paste bulk write code here"*/
    private TextView mPasteCodeHere;

    /* Stores user string*/
    String mUser ;

    /* Stores site string*/
    String mSite;

    //String mBulk_item_strings;

    String un_parsed;
    boolean is_write;

    TextView eView_example;

    BulkWriteItemCustomAdapter adapter;

    private String blockCharacterSet = "#";

    private InputFilter characterfilter = new InputFilter() {

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

            if (source != null && blockCharacterSet.contains(("" + source))) {
                return "";
            }
            return null;
        }
    };

    public static BulkWriteFragment newInstance()
    {
        BulkWriteFragment fragment = new BulkWriteFragment();

        Bundle args = new Bundle();

        args.putString(Bulk, "");
        args.putBoolean(Write, false);

        fragment.setArguments(args);

        return fragment;
    }

    public BulkWriteFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            un_parsed = getArguments().getString(Bulk);
            is_write = getArguments().getBoolean(Write);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View Bulk_Write_page_view = inflater.inflate(R.layout.fragment_bulk_write, container, false);

        /* Initialize list view present in current fragment to hold bulk write data*/
        mListView = (ListView)Bulk_Write_page_view.findViewById(R.id.list_Bulk_Write);

        /* Initialize text view present in current fragment that displays message "paste bulk write code here"*/
        mPasteCodeHere = (TextView) Bulk_Write_page_view.findViewById(R.id.textview_pastecodeheremessage);

        /* Initialize bulk write button*/
        btnBulkWrite = (Button) Bulk_Write_page_view.findViewById(R.id.btn_bulkwrite_tag_write);

        eView_example = (TextView) Bulk_Write_page_view.findViewById(R.id.Bulk_Write_tag_example);

        /* Set bulk write button on touch listener*/
        btnBulkWrite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    /* To give some click effect
                    * Background color will be made little transparent on touch down event.
                    * Restore original background on up event*/
                    btnBulkWrite.setBackground(getResources().getDrawable(R.drawable.button_back));

                    try {

                    /* See if bulk write test is display "Paste" or "Write"*/
                        if (!btnBulkWrite.getText().equals(getResources().getString(R.string.Write))) {
                        /* If bulk write button was displaying "Paste" text, it means user has pasted some data on this touch
                        * Go Parse Data after grabbing it from Clipboard
                        * */
                            if (parse_data()) {

                                // Save in arguments.
                                getArguments().putString(Bulk, un_parsed);
                                getArguments().putBoolean(Write, true);

                            /* If data is correctly parsed.
                            * Hide "Paste bulk write code here" message
                            * Set bulk write button text to write. Now, user can't paste more data unless clear is pressed.
                            * Show clear button.
                            * */
                                mPasteCodeHere.setVisibility(View.GONE);
                                btnBulkWrite.setText(R.string.Write);
                                btnClear.setVisibility(View.VISIBLE);
                            } else {
                                getArguments().putBoolean(Write, false);
                            /* If data parsing failed
                            * Keep "Paste bulk write code here" message visible
                            * Keep Bulk write button text "Paste"
                            * Keep Clear button hidden.
                            * */
                                mPasteCodeHere.setVisibility(View.VISIBLE);
                                btnBulkWrite.setText(R.string.Paste);
                                btnClear.setVisibility(View.GONE);
                            }
                        } else {
                            if (!get_NFC_state()) {
                                display_error_message(getString(R.string.nfc_disabled), NextAction.Enable_NFC);
                            } else {
                        /* If bulk write button has "Write" text, start writing*/
                                Signal_Write_Waiting();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.e(iError.App_TAG, ex.toString());
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    /* Just to give some click effect, make button background little
                    * transparent on touch down event.
                    * */
                    btnBulkWrite.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                }

                return true;
            }
        });

        /* Initialize clear button*/
        btnClear = (Button) Bulk_Write_page_view.findViewById(R.id.button_clear_bulkwrite_code);

        /* By default, make clear button in-visible as not data will be there to clear.*/
        btnClear.setVisibility(View.GONE);

        btnClear.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {

                    /* To give some click effect
                    * Background color will be made little transparent on touch down event.
                    * Restore original background on up event*/
                    btnClear.setBackground(getResources().getDrawable(R.drawable.button_back_gray));

                    try {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage(getString(R.string.are_you_sure)).setPositiveButton(getString(R.string.yes), dialogClickListener)
                                .setNegativeButton(getString(R.string.no), dialogClickListener).show();
                    }
                    catch (Exception ex)
                    {
                        Log.e(iError.App_TAG, ex.toString());
                    }
                }
                else
                {
                    btnClear.setBackgroundColor(getResources().getColor(R.color.indsci_gray_shade));
                }

                return false;
            }
        });


        if(un_parsed != null)
        {
            Parse_Strings(true);
        }

        if(is_write)
        {
            mPasteCodeHere.setVisibility(View.GONE);
            btnBulkWrite.setText(R.string.Write);
            btnClear.setVisibility(View.VISIBLE);
        }

        select_navigation_option();

        return Bulk_Write_page_view;
    }

    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    //Yes button clicked
                    mListView.setAdapter(null);

                    mPasteCodeHere.setVisibility(View.VISIBLE);
                    btnBulkWrite.setText(R.string.Paste);
                    btnClear.setVisibility(View.GONE);

                    getArguments().putString(Bulk, "");
                    getArguments().putBoolean(Write, false);

                    mListView.setVisibility(View.GONE);
                    eView_example.setVisibility(View.VISIBLE);

                    break;

                case DialogInterface.BUTTON_NEGATIVE:
                    //No button clicked
                    break;
            }
        }
    };


    private void Signal_Write_Waiting()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null)
        {
            getData(hActivity.Bulk_Write_records);
            hActivity.write_records();
            hActivity.Ready_To_Write_Flag = true;
        }
    }

    public void update_item(int pos, boolean status)
    {
        Bulk_Item item = adapter.getItem(pos);

        item.status = status? Passed : Failed;

        adapter.notifyDataSetChanged();
    }

    private void getData( List<TagDataRecord> _records)
    {
        _records.clear();

        int items = adapter.getCount();

        int fail_count = Failed_Count();

        for(int ind = 0; ind < items; ind++)
        {
            Bulk_Item dRecord = adapter.getItem(ind);

            if(dRecord.checked) {
                // If there are failed items, only program failed ones.
                if(fail_count != 0)
                {
                    if(dRecord.status == Passed)
                        continue;
                }
                //mUser = user.getText().toString();
                mUser = dRecord.user;

                //mSite = site.getText().toString();

                mSite = dRecord.site;

                if (mUser.equals("") && mSite.equals("") || mUser.equals(getString(R.string.incorrect_text)))
                    continue;

                // TODO: Fix placeholder for Access Level in bulk write
                TagDataRecord _record = new TagDataRecord(mUser, mSite, "0", false, false, ind);

                _records.add(_record);
            }
        }
    }

    private int Failed_Count()
    {
        int items = adapter.getCount();

        int fail_count = 0;

        for(int ind = 0; ind < items; ind++)
        {
            Bulk_Item dRecord = adapter.getItem(ind);

            if(dRecord.status == Failed)
            {
                fail_count++;
            }
        }

        return fail_count;
    }

    private boolean parse_data()
    {
        try
        {
            mListView.setAdapter(null);

            ClipboardManager clipboard = (ClipboardManager) getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard.hasPrimaryClip())
            {
                ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                un_parsed = item.getText().toString();
            }
            else
            {
                display_error_message(getString(R.string.nothing_to_paste), NextAction.Unknown);
                return false;
            }

            return Parse_Strings(false);
        }
        catch (Exception ex)
        {
            display_error_message(getString(R.string.failed_to_parse_values), NextAction.Unknown);
            return false;
        }
    }


    private boolean Parse_Strings(boolean isAuto)
    {
        if (!un_parsed.equals(""))
        {
            String[] lines = un_parsed.split("\n");

            Boolean status = true;

            final Bulk_Item[] Bulk_Write_Item = new Bulk_Item[lines.length];

            for (int index = 0; index < lines.length; index++)
            {
                String[] items = lines[index].replace("\r" , "").split("#");

                if (items.length >= 2)
                {
                    String user_string = items[0];
                    String site_string = items[1];

                    if(user_string.contains(getString(R.string.user_lower)+":") || user_string.contains(getString(R.string.User) +":"))
                    {
                        user_string = user_string.trim();

                        user_string = user_string.substring(5);

                        user_string = user_string.trim();

                        if(user_string.length() > 16)
                        {
                            user_string = user_string.substring(0,16);
                        }
                    }
                    else
                    {
                        user_string = "";
                    }

                    if(site_string.contains(getString(R.string.site_lower) + ":") || site_string.contains(getString(R.string.Site) +":"))
                    {
                        site_string = site_string.trim();

                        site_string = site_string.substring(5);

                        site_string = site_string.trim();

                        if(site_string.length() > 16)
                        {
                            site_string = site_string.substring(0,16);
                        }
                    }
                    else
                    {
                        site_string = "";
                    }

                    Bulk_Write_Item[index] = new Bulk_Item(R.drawable.ic_tick, user_string, site_string , true, New);
                }
                else if (items.length == 1)
                {
                    String field_string = items[0];

                    if(field_string.contains(getString(R.string.user_lower)+":") || field_string.contains(getString(R.string.User) +":"))
                    {
                        field_string = field_string.trim();

                        field_string = field_string.substring(5);

                        field_string = field_string.trim();

                        if(field_string.length() > 16)
                        {
                            field_string = field_string.substring(0,16);
                        }

                        Bulk_Write_Item[index] = new Bulk_Item(R.drawable.ic_tick, field_string, "" , true , New);
                    }
                    else if(field_string.contains(getString(R.string.site_lower) + ":") || field_string.contains(getString(R.string.Site) +":"))
                    {
                        field_string = field_string.trim();

                        field_string = field_string.substring(5);

                        field_string = field_string.trim();

                        if(field_string.length() > 16)
                        {
                            field_string = field_string.substring(0,16);
                        }

                        Bulk_Write_Item[index] = new Bulk_Item(R.drawable.ic_tick, "", field_string , true , New);
                    }
                    else
                    {
                        Bulk_Write_Item[index] = new Bulk_Item(R.drawable.ic_tick, "" , "", true, New);
                    }
                }
                else
                {

                    Bulk_Write_Item[index] = new Bulk_Item(R.drawable.ic_tick, "" , "", true, New);
                    //status = false;
                    //break;
                }
            }

//            if(!status)
//            {
//                display_error_message(getString(R.string.failed_to_parse_values),NextAction.Unknown);
//                return false;
//            }

            adapter = new BulkWriteItemCustomAdapter(getActivity(), R.layout.bulkwrite_list_item, Bulk_Write_Item);

            adapter.setNotifyOnChange(true);

            eView_example.setVisibility(View.GONE);
            mListView.setVisibility(View.VISIBLE);

            mListView.setAdapter(adapter);
            mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                    final TextView tv_user = (TextView) view.findViewById(R.id.textview_bulkitem_user_text);
                    final TextView tv_site = (TextView) view.findViewById(R.id.textview_bulkitem_site_text);
                    final ImageView img_user = (ImageView) view.findViewById(R.id.imageview_bulkitem_image);
                    final ImageView img_site = (ImageView) view.findViewById(R.id.imageview_bulkitem_image_site);

                    final LinearLayout lay_loc = (LinearLayout) view.findViewById(R.id.bulkwrite_item_loc_layout);

                    AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());

                    alert.setTitle("Edit");

                    View lay = getActivity().getLayoutInflater().inflate(R.layout.bulkwrite_list_item_edit, null);

                    final EditText user_edit = (EditText) lay.findViewById(R.id.textview_bulkitem_edit_user_text);

                    if(tv_user.getText().toString().equals(getString(R.string.incorrect_text)))
                        user_edit.setText("");
                    else
                        user_edit.setText(tv_user.getText().toString());

                    final EditText site_edit = (EditText) lay.findViewById(R.id.textview_bulkitem_edit_site_text);

                    site_edit.setText(tv_site.getText().toString());

                    site_edit.setFilters(new InputFilter[]{characterfilter , new InputFilter.LengthFilter(16)});

                    final TextView user_chars_count = (TextView) lay.findViewById(R.id.Bulk_Write_tag_edit_user_char_count);
                    user_edit.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {

                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                            int length = s.length();

                            user_chars_count.setText(length + "/16");

                            if (length == 16) {
                                user_chars_count.setTextColor(Color.RED);
                            } else {
                                user_chars_count.setTextColor(getResources().getColor(R.color.indsci_green));
                            }
                        }
                    });

                    user_edit.setFilters(new InputFilter[]{ characterfilter , new InputFilter.LengthFilter(16)});

                    final TextView site_chars_count = (TextView) lay.findViewById(R.id.Bulk_Write_tag_edit_site_char_count);
                    site_edit.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {

                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                            int length = s.length();

                            site_chars_count.setText(length + "/16");

                            if(length == 16)
                            {
                                site_chars_count.setTextColor(Color.RED);
                            }
                            else {
                                site_chars_count.setTextColor(getResources().getColor(R.color.indsci_green));
                            }
                        }
                    });

                    alert.setView(lay);

                    alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {

                            lay_loc.setVisibility(View.VISIBLE);

                            img_user.setImageResource(R.drawable.ic_user);
                            img_site.setImageResource(R.drawable.ic_site);

                            tv_user.setTextColor(getResources().getColor(R.color.indsci_dark_gray));
                            tv_user.setText(user_edit.getText().toString());
                            tv_site.setText(site_edit.getText().toString());
//
                            adapter.getItem(position).user = user_edit.getText().toString();
                            adapter.getItem(position).site = site_edit.getText().toString();

                           adapter.notifyDataSetChanged();

                            update_parsed_string();
                        }
                    });

                    alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // Canceled.
                        }
                    });
                    alert.show();
                }
            });

            return  true;
        }
        else
        {
            if(!isAuto) {
                display_error_message(getString(R.string.nothing_to_paste), NextAction.Unknown);
            }
            return false;
        }
    }

    private void update_parsed_string()
    {
        un_parsed = "";
        int items = adapter.getCount();

        for(int ind = 0; ind < items; ind++)
        {
            //Bulk_Item dRecord = (Bulk_Item)mListView.getItemAtPosition(ind);
            Bulk_Item dRecord = adapter.getItem(ind);

            //TextView user = (TextView) dRecord.findViewById(R.id.textview_bulkitem_user_text);
            //TextView site = (TextView) dRecord.findViewById(R.id.textview_bulkitem_site_text);

            //mUser = user.getText().toString();

            if(dRecord != null) {
                mUser = dRecord.user;

                if (mUser.equals(getString(R.string.incorrect_text))) {
                    mUser = "";
                }

                //mSite = site.getText().toString();
                mSite = dRecord.site;

                un_parsed += getString(R.string.User) + ":" + mUser + "#" + getString(R.string.Site) + ":" + mSite + "#" + "\n";
            }
        }

        getArguments().putString(Bulk, un_parsed);
    }

    public class Bulk_Item
    {
        public int icon;
        public String user;
        public String site;
        public Boolean checked;
        public int status;

        // Constructor.
        public Bulk_Item(int icon, String User, String Site, Boolean check, int statuss)
        {
            this.icon = icon;
            this.user = User;
            this.site = Site;
            this.checked =  check;
            this.status = statuss;
        }
    }

    static class Bulk_Item_View
    {
        ImageView imageViewIcon_user;
        ImageView imageViewIcon_site;
        TextView textView_Name;
        TextView textView_Site;
        LinearLayout bulkwrite_item_loc_lay;
        CheckBox mChecked;
        TextView mStatus;
    }

    public class BulkWriteItemCustomAdapter extends ArrayAdapter<Bulk_Item>
    {
        Context mContext;
        int layoutResourceId;
        Bulk_Item data[] = null;

        public BulkWriteItemCustomAdapter(Context mContext, int layoutResourceId, Bulk_Item[] data) {

            super(mContext, layoutResourceId, data);
            this.layoutResourceId = layoutResourceId;
            this.mContext = mContext;
            this.data = data;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            Bulk_Item_View viewHolder;

            View listItem;

            if(convertView == null) {
                LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
                convertView = inflater.inflate(layoutResourceId, parent, false);

                viewHolder = new Bulk_Item_View();
                viewHolder.textView_Name = (TextView) convertView.findViewById(R.id.textview_bulkitem_user_text);
                viewHolder.textView_Site = (TextView) convertView.findViewById(R.id.textview_bulkitem_site_text);
                viewHolder.imageViewIcon_user = (ImageView) convertView.findViewById(R.id.imageview_bulkitem_image);
                viewHolder.imageViewIcon_site = (ImageView) convertView.findViewById(R.id.imageview_bulkitem_image_site);
                viewHolder.bulkwrite_item_loc_lay = (LinearLayout) convertView.findViewById(R.id.bulkwrite_item_loc_layout);

                viewHolder.mChecked = (CheckBox) convertView.findViewById(R.id.checkbox_bulkitem_checkbox);
                viewHolder.mStatus = (TextView) convertView.findViewById(R.id.textview_bulkitem_status);
                viewHolder.mStatus.setText("");

                convertView.setTag(viewHolder);
            }
            else {
                viewHolder = (Bulk_Item_View) convertView.getTag();
            }

            final Bulk_Item item = data[position];

            if(item != null) {
                if (item.user.equals("") && item.site.equals("")) {

                    viewHolder.bulkwrite_item_loc_lay.setVisibility(View.GONE);

                    viewHolder.imageViewIcon_user.setImageResource(R.drawable.ic_warning);
                    //viewHolder.imageViewIcon_site.setImageResource(R.drawable.ic_warning);
                    viewHolder.textView_Name.setTextColor(Color.RED);
                    viewHolder.textView_Name.setText(getString(R.string.incorrect_text));
                    viewHolder.textView_Site.setText("");
                } else {

                    viewHolder.bulkwrite_item_loc_lay.setVisibility(View.VISIBLE);
                    viewHolder.imageViewIcon_user.setImageResource(R.drawable.ic_user);
                    //viewHolder.imageViewIcon.setImageResource(item.icon);
                    viewHolder.textView_Name.setTextColor(getResources().getColor(R.color.indsci_dark_gray));
                    viewHolder.textView_Name.setText(item.user);
                    viewHolder.textView_Site.setText(item.site);

                    viewHolder.mChecked.setChecked(item.checked);
                    viewHolder.mChecked.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            item.checked = isChecked;
                        }
                    });

                    if(item.status == Passed)
                    {
                        viewHolder.mStatus.setText(getString(R.string.Written));
                        viewHolder.mStatus.setVisibility(View.VISIBLE);
                        viewHolder.mStatus.setBackgroundColor(getResources().getColor(R.color.indsci_green));
                    }
                    else if(item.status == Failed)
                    {
                        viewHolder.mStatus.setText(getString(R.string.Failed));
                        viewHolder.mStatus.setVisibility(View.VISIBLE);
                        viewHolder.mStatus.setBackgroundColor(getResources().getColor(R.color.indsci_red));
                    }
                    else
                    {
                        viewHolder.mStatus.setText("");
                        viewHolder.mStatus.setVisibility(View.GONE);
                    }
                }
            }
            else
            {
                viewHolder.bulkwrite_item_loc_lay.setVisibility(View.GONE);

                viewHolder.imageViewIcon_user.setImageResource(R.drawable.ic_warning);
                //viewHolder.imageViewIcon_site.setImageResource(R.drawable.ic_warning);
                viewHolder.textView_Name.setTextColor(Color.RED);
                viewHolder.textView_Name.setText(getString(R.string.incorrect_text));
                viewHolder.textView_Site.setText("");
            }

            return convertView;
        }
    }

    private void select_navigation_option()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.select_page(4);
        }
    }

    private boolean get_NFC_state()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            return hActivity.getNFC_state();
        }

        return false;
    }

    private void display_error_message(String msg, NextAction _next)
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.display_error_dialog(msg, _next, true);
        }
    }

}