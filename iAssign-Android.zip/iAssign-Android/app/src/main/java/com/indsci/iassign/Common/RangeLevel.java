package com.indsci.iassign.Common;

import com.indsci.iassign.R;

import java.util.ArrayList;

/**
 * Created by JAgostoni on 7/12/2016.
 */
public enum RangeLevel {

    LEVELC("C", R.string.beacon_level_c),
    LEVELB("B", R.string.beacon_level_b),
    LEVELA("A", R.string.beacon_level_a),
    LEVEL8("8", R.string.beacon_level_8);

//    LEVEL9("9", R.string.beacon_level_9),
//    LEVELB("B", R.string.beacon_level_b),
//    LEVEL0("0", R.string.beacon_level_0);
//    LEVEL1("1", R.string.beacon_level_1),
//    LEVEL2("2", R.string.beacon_level_2),
//    LEVEL3("3", R.string.beacon_level_3),
//    LEVEL4("4", R.string.beacon_level_4),
//    LEVEL7("7", R.string.beacon_level_7),
//    LEVELF("F", R.string.beacon_level_F);

    private String level;
    private  int id;

    RangeLevel(String rangeLevel, int resourceId) {
        level = rangeLevel;
        id = resourceId;
    }

    @Override
    public String toString() {
        return IAssignApplication.getContext().getString(id);
    }

    public static RangeLevel fromString(String val) {
        for (RangeLevel v: values()) {
            if (v.toString().equals(val)) {
                return v;
            }
        }
        return null;
    }

    public static ArrayList<String> toIdList() {
        ArrayList<String> _rangeValues = new ArrayList<>();
        for (RangeLevel rl : RangeLevel.values()) {
            _rangeValues.add(rl.toString());
        }
        return _rangeValues;
    }

    public String toValue() { return level; }


    public static RangeLevel fromValue(String level) {
        for (RangeLevel v: values()) {
            if(v.level.equals(level)) {
                return v;
            }
        }

        return null;
    }
}
