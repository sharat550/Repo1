package com.indsci.iassign.Cards;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.indsci.iassign.Common.CardDataRecord;
import com.indsci.iassign.Common.CardType;
import com.indsci.iassign.HomeActivity;
import com.indsci.iassign.R;


/**
 * Created by mkloszewski on 8/9/2016.
 */
public class CardReadFragment extends Fragment {
    private TextView _cardTypeText;
    private TextView _activationsUsedText;
    private ListView _activatedDevicesListView;

    private HomeActivity _Home;

    private CardDataRecord _record;

    private int _activationsUsed;
    private int _activationsCapacity;

    private String _cardType;

    public CardReadFragment() {
        // Empty public constructor
    }

    public static CardReadFragment newInstance(CardDataRecord record) {
        Bundle args = new Bundle();
        CardReadFragment fragment = new CardReadFragment();
        if (record != null) {
            args.putInt("CardType", record.getCardType());
            args.putInt("UnlockCount", record.getUnlockCount());
            args.putInt("SavedSerialCount", record.getSavedSerialCount());
            args.putStringArray("ActivatedSerials", record.getActivatedSerials());
        }

        fragment.setRecord(record);
        fragment.setArguments(args);
        return fragment;
    }

    public void setRecord(CardDataRecord record) {
        this._record = record;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        _Home = (HomeActivity) getActivity();

        if(_Home.read_dialog != null) {
            if (_Home.read_dialog.isShowing()) {
                _Home.read_dialog.dismiss();
            }
        }

        if (_record == null) {
            _record = new CardDataRecord();
        }
        if (getArguments() != null) {
            _record.setCardType(getArguments().getInt("CardType"));
            _record.setUnlockCount(getArguments().getInt("UnlockCount"));
            _record.setSavedSerialCount(getArguments().getInt("SavedSerialCount"));
            _record.setActivatedSerials(getArguments().getStringArray("ActivatedSerials"));
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View inflated = inflater.inflate(R.layout.fragment_card_read, container, false);

        // TODO : Replace placeholder values
        _activationsUsed = _record.getSavedSerialCount();
        _activationsCapacity = (_record.getSavedSerialCount() + _record.getUnlockCount());
        _cardType = CardType.fromValue(_record.getCardType()).toString();

        _cardTypeText = (TextView) inflated.findViewById(R.id.editbox_card_type);
        _cardTypeText.setText(_cardType);

        _activationsUsedText = (TextView) inflated.findViewById(R.id.editbox_activations_used);
        _activationsUsedText.setText(_activationsUsed + " " + getString(R.string.of) + " " + _activationsCapacity);

        _activatedDevicesListView = (ListView) inflated.findViewById(R.id.card_serial_listview);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(_Home, R.layout.serial_list_element_view, _record.getActivatedSerials());
        _activatedDevicesListView.setAdapter(adapter);

        return inflated;
    }

}
