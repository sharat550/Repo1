package com.indsci.iassign;

import android.app.FragmentManager;
import android.os.Bundle;
import android.app.Fragment;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import com.indsci.iassign.Common.TagDataRecord;
import com.indsci.iassign.Common.FrameNames;
import com.indsci.iassign.Common.NextAction;
import com.indsci.iassign.Common.TextCountWatcher;
import com.indsci.iassign.Common.UserAccessLevel;

public class WriteTagFragment extends Fragment
{
    private static final String User = "User";
    private static final String Site = "Site";
    private static final String Access = "Access";
    private static final String OverWrite = "Overwrite";
    private static final String Lock = "Lock";

    EditText eUser;
    EditText eSite;

    TextView eUser_Char_Count;
    TextView eSite_Char_Count;

    CheckBox cLockTag;

    Button btnWriteTag;

    Spinner _AccessLevel;

    String mUser;
    String mSite;
    String mAccess;

    String mUser_new;
    String mSite_new;
    String mAccess_new;

    Boolean mLock;

    HomeActivity _Home;

    boolean mOverwrite;

    private String blockCharacterSet = ":#";

    private InputFilter characterfilter = new InputFilter() {

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {

            if (source != null
                    && blockCharacterSet.contains(("" + source))
                    || ((int) source.charAt(0) < 32)                // IASGN-2 - Restrict to printable ASCII chars
                    || ((int) source.charAt(0) > 127)
                    ) {
                return "";
            }
            return null;
        }
    };

    public static WriteTagFragment newInstance(TagDataRecord _record , boolean overwrite)
    {
        WriteTagFragment fragment = new WriteTagFragment();
        Bundle args = new Bundle();

        if(_record != null) {
            args.putString(User, _record.getUser());
            args.putString(Site, _record.getSite());
            args.putString(Access, _record.getAccess());
            args.putBoolean(Lock, _record.getLocked());
        }
        else
        {
            args.putString(User, "");
            args.putString(Site, "");
            args.putString(Access,"");
            args.putBoolean(Lock, false);
        }

        args.putBoolean(OverWrite, overwrite);

        fragment.setArguments(args);
        return fragment;
    }

    public WriteTagFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUser = getArguments().getString(User);
            mSite = getArguments().getString(Site);
            mAccess = getArguments().getString(Access);
            mLock = getArguments().getBoolean(Lock);

            mOverwrite = getArguments().getBoolean(OverWrite);
        }

        _Home = (HomeActivity) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View V = inflater.inflate(R.layout.fragment_write_tag, container, false);

        initialize_view(V);

        if(mOverwrite)
        {
            // save in arguments that we are served already for over write.
            getArguments().putBoolean(OverWrite, false);

            // Display alert showing that writing user, site...tag again.
            //display_writing_tag_dialog(V, mUser, mSite);

            // Signal Main Activity to start return the intent as write frame is
            // waiting to write the tag.
            Signal_Write_Waiting(mUser, mSite, mAccess, mLock);
        }

        select_navigation_option();

        return V;
    }

    public void initialize_view(View v)
    {
        _AccessLevel = (Spinner) v.findViewById(R.id.tag_access_level);
        _AccessLevel.setAdapter(new ArrayAdapter<>(v.getContext(), android.R.layout.simple_list_item_1, UserAccessLevel.toIdList()));

        if(_AccessLevel != null) {

            String stringLevel = getArguments().getString(Access);
            UserAccessLevel level = UserAccessLevel.fromValue(stringLevel);

            ArrayAdapter<String> levels = (ArrayAdapter<String>) _AccessLevel.getAdapter();
            if(level != null) {
                _AccessLevel.setSelection(levels.getPosition(level.toString()));
            } else {
                levels.add(stringLevel);
                _AccessLevel.setSelection(levels.getPosition(stringLevel));
            }
        }

        btnWriteTag = (Button) v.findViewById(R.id.btn_write_tag_write);
        btnWriteTag.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if(event.getAction() == MotionEvent.ACTION_UP) {

                    btnWriteTag.setBackground(getResources().getDrawable(R.drawable.button_back));

                    if(!get_NFC_state())
                    {
                        display_error_message(getString(R.string.nfc_disabled),NextAction.Enable_NFC);
                    }
                    else {

                        mUser_new = eUser.getText().toString();
                        mSite_new = eSite.getText().toString();
                        UserAccessLevel nl = UserAccessLevel.fromString(_AccessLevel.getSelectedItem().toString());
                        if(nl != null) {
                            mAccess_new = nl.toValue();
                        } else {
                            mAccess_new = _AccessLevel.getSelectedItem().toString();
                        }
                        mUser_new = mUser_new.trim();
                        mSite_new = mSite_new.trim();
                        mAccess_new = mAccess_new.trim();

                        mLock = cLockTag.isChecked();


                        // Updated regarding "[DEVJIRA2] (VAUG-446) Writing user or site on NFC tag"
                        // Empty User and Site will not be replaced with values.
                        // It will not be written to NFC tag record.

                        // // Don't update empty string. Replace with old string if empty.
                        //if (mUser_new.equals("")) {
                        //    mUser_new = mUser;
                        //}

                        //if (mSite_new.equals("")) {
                        //    mSite_new = mSite;
                        //}

                        // If old values are not empty, present user overwrite permission page.
                        // else go ahead writing
                        // if values are same as old. Don't show overwrite screen.
                        if (!mUser.equals("") && !mSite.equals("")) {
                            // TODO: Revisit this after asking about reading & confirmation screens
                            startOver_write_Fragment(mUser, mSite, mAccess, mUser_new, mSite_new, mAccess_new, mLock);
                        } else {
                            // Display alert showing that writing user, site...tag again.
                            //display_writing_tag_dialog(v, mUser_new, mSite_new);

                            // Signal Main Activity to start return the intent as write frame is
                            // waiting to write the tag.
                            if (mUser_new.equals("") && mSite_new.equals("")) {
                                eUser.setText("");
                                eSite.setText("");
                                display_error_message(getString(R.string.user_site_empty), NextAction.Unknown);
                            } else {
                                Signal_Write_Waiting(mUser_new, mSite_new, mAccess_new, mLock);
                            }
                        }
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    btnWriteTag.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                }

                return  true;
            }
        });

        eUser_Char_Count = (TextView) v.findViewById(R.id.write_tag_user_char_count);
        eUser = (EditText) v.findViewById(R.id.editbox_writetag_user);
        eUser.addTextChangedListener(new TextCountWatcher(eUser_Char_Count, 16));
        eUser.setFilters(new InputFilter[]{characterfilter, new InputFilter.LengthFilter(16)});

        eSite_Char_Count = (TextView)v.findViewById(R.id.write_tag_site_char_count);
        eSite = (EditText) v.findViewById(R.id.editbox_writetag_site);
        eSite.addTextChangedListener(new TextCountWatcher(eSite_Char_Count, 16));
        eSite.setFilters(new InputFilter[]{characterfilter , new InputFilter.LengthFilter(16)});

        cLockTag = (CheckBox) v.findViewById(R.id.writetag_cbox_locktag);

        if (!mUser.equals("") && mUser != null) {
            eUser.setText(mUser);
        }
        if (!mSite.equals("") && mSite != null) {
            eSite.setText(mSite);
        }

        cLockTag.setChecked(mLock);
    }

    private void Signal_Write_Waiting(String user, String site, String access, Boolean lock_tag)
    {

        if(_Home != null)
        {
            TagDataRecord newRecord = new TagDataRecord();
            newRecord.setUser(user);
            newRecord.setSite(site);
            newRecord.setAccess(access);
            _Home.display_writing_tag_dialog(newRecord,lock_tag);
            _Home.Ready_To_Write_Flag = true;

            /* Clear bulk write records at write as it can start writing bulk write tag after writing single tag
            * through this page
            * */
            _Home.Bulk_Write_records.clear();
        }
    }

    @Override
    public void onStop ()
    {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        if (_Home != null) {
            _Home.dismiss_writing_dialog();
            _Home.Ready_To_Write_Flag = false;
        }

        super.onDestroy();
    }

    public  void startOver_write_Fragment(String user_old, String site_old, String access_old, String user_new, String site_new, String access_new, boolean lock)
    {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, OverWriteFragment.newInstance(user_old, site_old, access_old, user_new, site_new, access_new, lock) , FrameNames.over_write_fragment_tag_string)
                .addToBackStack(FrameNames.over_write_fragment_tag_string)
                .commit();
    }

    private void select_navigation_option()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.select_page(2);
        }
    }

    private boolean get_NFC_state()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            return hActivity.getNFC_state();
        }

        return false;
    }

    private void display_error_message(String msg, NextAction _next)
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.display_error_dialog(msg, _next, true);
        }
    }

}
