package com.indsci.iassign.Common;

import com.indsci.iassign.R;

/**
 * Created by Mike Kloszewski on 8/19/2016.
 * Enum that represents the various types of activation cards.
 */
public enum CardType {
    TYPE1(1, R.string.card_type_lens),
    TYPE2(2, R.string.card_type_inet);

    private int cardType;
    private int resourceId;

    CardType(int type, int id) {
        cardType = type;
        resourceId = id;
    }

    /**
     * Returns the int value of the enum entry.
     * @return
     */
    public int toValue() { return cardType; }

    /**
     * Takes an int value read from a wireless card and returns the CardType.
     * @param val The int passed in, representing a card spec.
     * @return Returns the associated CardType, or null if not found in enum.
     */
    public static CardType fromValue(int val) {
        for (CardType t : values()) {
            if (t.cardType == val) {
                return t;
            }
        }
        return null;
    }

    /**
     * Returns the string resource associated with this enum value.
     * @return Wireless card's name as a string.
     */
    @Override
    public String toString() {
        return IAssignApplication.getContext().getString(resourceId);
    }

}
