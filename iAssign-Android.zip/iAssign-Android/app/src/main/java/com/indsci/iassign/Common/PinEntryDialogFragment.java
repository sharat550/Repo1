package com.indsci.iassign.Common;


import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.indsci.iassign.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class PinEntryDialogFragment extends DialogFragment {

    public static final String PIN_TO_CONFIRM_ARG = "com.indsci.iassign.pin.confirmation.arg";
    private static final String MASTER_UNLOCK_PIN = "0412";

    EditText _PINEditText;
    TextView _PINLabel;
    PINEntryListener _Listener;
    Button _CancelButton;
    Button _ContinueButton;
    Boolean _FirstTry = true;
    String _PINValue;
    Boolean _PINIsSet = false;
    Boolean _PINCanceled = false;

    Boolean _PINConfirmationMode = false;

    public PinEntryDialogFragment() {
        // Required empty public constructor
    }

    public static PinEntryDialogFragment newInstance() {
        return newInstance(null);
    }


    public static PinEntryDialogFragment newInstance(String pinToConfirm) {
        Bundle args = new Bundle();

        if(pinToConfirm != null) {
            args.putString(PIN_TO_CONFIRM_ARG, pinToConfirm);
        }

        PinEntryDialogFragment fragment = new PinEntryDialogFragment();
        fragment.setArguments(args);
        return fragment;

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_pin_entry_dialog, container, false);

        _PINEditText = (EditText) inflated.findViewById(R.id.pin_entry_text);
        _PINEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                continuePINEntry();
                return false;
            }
        });

        _PINLabel = (TextView) inflated.findViewById(R.id.pin_label_text);

        if(_PINConfirmationMode) {
            _PINLabel.setText(R.string.pin_entry_unlock_label);
        }

        _CancelButton = (Button) inflated.findViewById(R.id.pin_cancel_button);
        _CancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                _PINCanceled = true;
                if(_Listener != null) {
                    _Listener.pinEntryCanceled();
                }

                dismiss();
            }
        });


        _ContinueButton = (Button) inflated.findViewById(R.id.pin_continue_button);
        _ContinueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                continuePINEntry();
            }
        });


        return inflated;
    }

    private void continuePINEntry() {
        if(_FirstTry && !_PINConfirmationMode) {
            String pin = _PINEditText.getText().toString();

            if(pin.length() != 4) {
                _PINLabel.setText(R.string.pin_must_be_digits);
                _PINEditText.setHint(R.string.pin_must_be_digits);
            } else {
                _PINLabel.setText(R.string.pin_confirm_pin);
                _PINEditText.setHint(R.string.pin_reenter_pin);
                _FirstTry = false;
                _PINValue = pin;
                _PINEditText.setText("");
            }

        } else {
            String pinAgain = _PINEditText.getText().toString();

            // First check for master unlock pin if trying to unlock
            if (pinAgain.equals(MASTER_UNLOCK_PIN) && _PINConfirmationMode) {
                _PINIsSet = true;
                if(_Listener != null) {
                    _Listener.pinEntryCompleted(_PINValue);
                    dismiss();
                }
            }
            // If not master unlock pin, check against unlock pin read from beacon
            else if(!pinAgain.equals(_PINValue)) {
                if(!_PINConfirmationMode) {
                    _PINLabel.setText(R.string.pin_did_not_match);
                    _PINValue = "";
                } else {
                    _PINLabel.setText(R.string.pin_entry_unlock_fail);
                }
                _PINEditText.setHint(R.string.pin_enter_pin);
                _FirstTry = true;
                _PINEditText.setText("");
            } else {
                _PINIsSet = true;
                if(_Listener != null) {
                    _Listener.pinEntryCompleted(_PINValue);
                    dismiss();
                }
            }
        }
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, getTheme());

        Bundle args = this.getArguments();
        if(args != null) {
            String pin =  args.getString(PIN_TO_CONFIRM_ARG);

            if(pin != null) {
                _PINValue = pin;
                _PINConfirmationMode = true;
            }
        }
    }


    @Override
    public void onDismiss(DialogInterface dialog) {
        if(_Listener != null && !_PINIsSet && !_PINCanceled) {
            _Listener.pinEntryCanceled();
        }

        super.onDismiss(dialog);
    }

    public void setOnPINEntryListener(PINEntryListener listener) {
        _Listener = listener;
    }

    public interface PINEntryListener {
        void pinEntryCanceled();
        void pinEntryCompleted(String pinValue);
    }
}
