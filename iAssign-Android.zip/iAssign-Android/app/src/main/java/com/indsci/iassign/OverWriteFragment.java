package com.indsci.iassign;

import android.app.FragmentManager;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.indsci.iassign.Common.TagDataRecord;
import com.indsci.iassign.Common.FrameNames;
import com.indsci.iassign.Common.UserAccessLevel;

public class OverWriteFragment extends Fragment
{
    private static final String User_Old = "User_Old";
    private static final String Site_Old = "Site_Old";
    private static final String Access_Old = "Access_Old";

    private static final String User_New = "User_New";
    private static final String Site_New = "Site_New";
    private static final String Access_New = "Access_New";

    private static final String Lock = "Lock";

    private String mUserOld;
    private String mSiteOld;

    private String mUserNew;
    private String mSiteNew;

    private String mAccessOld;
    private String mAccessNew;

    private boolean mLock;

    TextView eUser_Old;
    TextView eSite_Old;
    TextView eAccess_Old;

    TextView eUser_New;
    TextView eSite_New;
    TextView eAccess_New;

    Button btnYes;
    Button btnNo;

    public static OverWriteFragment newInstance(String user_old, String site_old , String access_old, String user_new, String site_new, String access_new, boolean lock)
    {
        OverWriteFragment fragment = new OverWriteFragment();
        Bundle args = new Bundle();

        args.putString(User_Old, user_old);
        args.putString(Site_Old, site_old);
        args.putString(Access_Old,access_old);

        args.putString(User_New, user_new);
        args.putString(Site_New, site_new);
        args.putString(Access_New, access_new);

        args.putBoolean(Lock, lock);

        fragment.setArguments(args);

        return fragment;
    }

    public OverWriteFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUserOld = getArguments().getString(User_Old);
            mSiteOld = getArguments().getString(Site_Old);
            mAccessOld = getArguments().getString(Access_Old);

            mUserNew = getArguments().getString(User_New);
            mSiteNew = getArguments().getString(Site_New);
            mAccessNew = getArguments().getString(Access_New);

            mLock = getArguments().getBoolean(Lock);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View over_write_view = inflater.inflate(R.layout.fragment_over_write, container, false);

        eUser_Old = (TextView) over_write_view.findViewById(R.id.textview_overwrite_existing_user);
        eSite_Old = (TextView) over_write_view.findViewById(R.id.textview_overwrite_existing_site);
        eAccess_Old = (TextView) over_write_view.findViewById(R.id.textview_overwrite_existing_access);

        eUser_New = (TextView) over_write_view.findViewById(R.id.textview_overwrite_new_user);
        eSite_New = (TextView) over_write_view.findViewById(R.id.textview_overwrite_new_site);
        eAccess_New = (TextView) over_write_view.findViewById(R.id.textview_overwrite_new_access);

        eUser_Old.setText(mUserOld);
        eSite_Old.setText(mSiteOld);

        if (mAccessOld != null && mAccessOld.length() >= 1) {
            UserAccessLevel level = UserAccessLevel.fromValue(mAccessOld);
            if(level != null) {
                eAccess_Old.setText(level.toString());
            } else {
                eAccess_Old.setText(mAccessOld);
            }
        }
        else {
            eAccess_Old.setText("No Value");
        }


        if(mUserNew.equals(""))
        {
            eUser_New.setTextColor(Color.RED);
            eUser_New.setText(mUserOld);
        }
        else {
            eUser_New.setText(mUserNew);
        }

        if(mSiteNew.equals(""))
        {
            eSite_New.setTextColor(Color.RED);
            eSite_New.setText(mSiteOld);
        }
        else {
            eSite_New.setText(mSiteNew);
        }

        UserAccessLevel newLevel = UserAccessLevel.fromValue(mAccessNew);
        if(newLevel != null) {
            eAccess_New.setText(newLevel.toString());
        } else {
            eAccess_New.setText(mAccessNew);
        }

        btnYes = (Button) over_write_view.findViewById(R.id.btn_overwritetag_yes);
        btnYes.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    btnYes.setBackground(getResources().getDrawable(R.drawable.button_back));
                    start_write_Fragment(mUserNew, mSiteNew, mAccessNew, true, mLock);
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    btnYes.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                }

                return  true;
            }
        });

        btnNo = (Button) over_write_view.findViewById(R.id.btn_writetag_overwrite_no);
        btnNo.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    btnNo.setBackground(getResources().getDrawable(R.drawable.button_back));
                    start_write_Fragment(mUserNew, mSiteNew, mAccessNew, false, mLock);
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    btnNo.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                }

                return  true;
            }
        });

        return over_write_view;
    }


    public  void start_write_Fragment(String user, String site , String access, boolean overwrite, boolean lock_tag)
    {
        TagDataRecord dRecord = new TagDataRecord(user, site , access, false,lock_tag,0);

        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, WriteTagFragment.newInstance(dRecord , overwrite) , FrameNames.write_tag_fragment_tag_string)
                .addToBackStack(FrameNames.write_tag_fragment_tag_string)
                .commit();
    }
}
