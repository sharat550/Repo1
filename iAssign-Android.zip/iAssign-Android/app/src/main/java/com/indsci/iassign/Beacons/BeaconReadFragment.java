package com.indsci.iassign.Beacons;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.indsci.iassign.Common.*;
import com.indsci.iassign.HomeActivity;
import com.indsci.iassign.R;

public class BeaconReadFragment extends Fragment {
    private TextView _Site;
    private TextView _Range;
    private TextView _Mode;
    private TextView _AccessLevel;
    private TextView _Serial;
    private TextView _LockedLabel;
    private Button _Edit;

    private String _serialNum;
    private String _unlockPIN;

    private PinEntryDialogFragment entryFragment;

    private BeaconDataRecord Record;

    private HomeActivity _Home;


    public BeaconReadFragment() {
        // Required empty public constructor
    }

    public static BeaconReadFragment newInstance(BeaconDataRecord record, byte[] serialNo, byte[] deviceUnlockPIN) {

        Bundle args = new Bundle();
        BeaconReadFragment fragment = new BeaconReadFragment();

        if(record != null) {
            args.putString("Site", record.getSite());
            args.putString("Range", record.getRange());
            args.putString("Mode", record.getMode());
            args.putString("Access", record.getAccess());
            args.putString("Serial", fragment.setSerial(serialNo));
            args.putString("PIN", fragment.setUnlockPIN(deviceUnlockPIN));
            args.putBoolean("Locked", record.getLocked());
        }

        fragment.setArguments(args);
        fragment.setRecord(record);

        return fragment;
    }

    public static BeaconReadFragment newInstance() {
        return newInstance();
    }


    public void setRecord(BeaconDataRecord record) {
        Record = record;
        loadDataInViews();
    }

    /**
     * Converts the byte array read from the beacon's serial area into an ASCII string.
     * @param serial The input bytes to decode
     * @return The beacon's serial as a string
     */
    public String setSerial(byte[] serial) {
        if(serial == null || serial.length < 8) {
            return "N/A";
        } else {
            String _serial = new String();
            for (int i = 0; i < 8; i++) {
                _serial = _serial + (char) serial[i];
            }
            return _serial;
        }
    }

    /**
     * Parses and decodes the pin code hash from the beacon into a string of 4 digits.
     * @param pin The byte array to parse and decode.
     * @return A string representation of the 4-digit pin.
     */
    private String setUnlockPIN(byte[] pin) {
        byte[] hashKey = new byte[] {(byte)0x00, (byte)0x04, (byte)0x01, (byte)0x02};

        /* If there is a read error or somehow corrupted pin, device can still be unlocked with master PIN.
           This return value will not actually be used,but is primarily meant to ensure that a
           null reference is not thrown when referencing the fragment's arguments.*/
        if(pin == null || pin.length < 4) {
            return "0412";
        }
        // Decode the hashed PIN by reversing the XOR operation.
        else {
            String pinString = "";
            for (int x = 0; x < 4; x++) {
                pin[x] = (byte)(pin[x] ^ hashKey[x]);
                pinString = pinString + String.valueOf(pin[x]);
            }
            return pinString;
        }

    }



    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        _Home = (HomeActivity) getActivity();

        // Retrieve a reference to the "Scan beacon" dialog and dismiss it
        BeaconHomePageFragment ParentFragment = (BeaconHomePageFragment)getFragmentManager().findFragmentByTag(FrameNames.beacon_home_page_fragment_string);
        if (ParentFragment != null) {
            ParentFragment.dismiss_read_beacon_dialog();
        }

        if (Record == null) {
            Record = new BeaconDataRecord();
        }
        if (getArguments() != null) {
            Record.setSite(getArguments().getString("Site"));
            Record.setRange(getArguments().getString("Range"));
            Record.setMode(getArguments().getString("Mode"));
            Record.setAccess(getArguments().getString("Access"));
            Record.setLocked(getArguments().getBoolean("Locked"));
            _serialNum = getArguments().getString("Serial");
            _unlockPIN = getArguments().getString("PIN");
        }

        

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_beacon_read, container, false);

        // Set up view references
        _Site = (TextView) inflated.findViewById(R.id.beacon_site);
        _Range = (TextView) inflated.findViewById(R.id.beacon_range);
        _Mode = (TextView) inflated.findViewById(R.id.beacon_mode);
        _AccessLevel = (TextView) inflated.findViewById(R.id.beacon_level);
        _Serial = (TextView) inflated.findViewById(R.id.beacon_serial);
        _LockedLabel = (TextView) inflated.findViewById(R.id.beacon_locked_label);
        _Edit = (Button) inflated.findViewById(R.id.btn_readbeacon_edit_button);
        _Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Record.getLocked()) {
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    Fragment prev = getFragmentManager().findFragmentByTag(FrameNames.beacon_pin_entry_fragment_string);
                    if (prev != null) {
                        ft.remove(prev);
                    }
                    ft.addToBackStack(FrameNames.beacon_pin_entry_fragment_string);

                    // Create and show the dialog.
                    entryFragment = PinEntryDialogFragment.newInstance(_unlockPIN);
                    entryFragment.setOnPINEntryListener(new PinEntryDialogFragment.PINEntryListener() {
                        @Override
                        public void pinEntryCanceled() {
                        }

                        @Override
                        public void pinEntryCompleted(String pinValue) {

                            _Home.Ready_To_Write_Flag = true;
                            _Home.Unlocking_Beacon_Flag = true;
                            BeaconDataRecord dummyRecord = new BeaconDataRecord();
                            dummyRecord.setSite("");
                            dummyRecord.setAccess("");
                            dummyRecord.setRange("");
                            dummyRecord.setMode("");
                            _Home.display_writing_beacon_dialog(dummyRecord, false);
                        }
                    });
                    entryFragment.show(ft, FrameNames.beacon_pin_entry_fragment_string);
                } else {
                    BeaconWriteFragment writeBeacon = BeaconWriteFragment.newInstance(Record);
                    HomeActivity.PushFragment(getFragmentManager(), writeBeacon, FrameNames.beacon_write_page_fragment_string);
                }
            }
        });

        loadDataInViews();
        return inflated;
    }


    private void loadDataInViews() {
        if(Record != null) {
            if(_Site != null) {
                _Site.setText(Record.getSite());
            }

            if(_Range != null) {
                RangeLevel l = RangeLevel.fromValue(Record.getRange());
                _Range.setText(l != null ? l.toString() : Record.getRange());
            }

            if(_Mode != null) {
                BeaconMode m = BeaconMode.fromValue(Record.getMode());
                _Mode.setText(m != null ? m.toString() : Record.getMode());
            }

            if(_AccessLevel != null) {
                BeaconAccessLevel a = BeaconAccessLevel.fromValue(Record.getAccess());
                _AccessLevel.setText(a!= null ? a.toString() : Record.getAccess());
            }

            if(_Serial != null) {
                _Serial.setText(_serialNum);
            }

            if(_LockedLabel != null) {
                _LockedLabel.setVisibility(Record.getLocked() ? View.VISIBLE : View.GONE);
            }

            if(_Edit != null) {
                if(Record.getLocked()) {
                    _Edit.setText(R.string.unlock);
                } else {
                    _Edit.setText(R.string.Edit);
                }
            }
        }
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);

    }

    @Override
    public void onPause() {
        if (entryFragment != null) {
            entryFragment.dismiss();
            entryFragment = null;
        }
        super.onPause();
    }




}
