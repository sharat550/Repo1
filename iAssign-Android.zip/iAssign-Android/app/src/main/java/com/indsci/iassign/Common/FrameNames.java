package com.indsci.iassign.Common;

public class FrameNames {
    public static final String home_fragment_tag_string = "isc_app_home_fragment";
    public static final String tag_home_fragment_tag_string = "isc_app_tag_home_fragment";
    public static final String read_tag_fragment_tag_string = "isc_app_read_tag_fragment";
    public static final String write_tag_fragment_tag_string = "isc_app_write_tag_fragment";
    public static final String buy_iassign_fragment_string = "isc_app_buy_iassign_fragment";
    public static final String Bulk_Write_fragment_tag_string = "isc_app_Bulk_Write_fragment";

    public static final String about_fragment_tag_string = "isc_app_about_fragment";
    public static final String legal_fragment_tag_string = "isc_app_legal_fragment";
    public static final String language_fragment_tag_string = "isc_app_language_fragment";
    public static final String feedback_fragment_tag_string = "isc_app_feedback_fragment";
    public static final String help_fragment_tag_string = "isc_app_help_fragment";

    public static final String over_write_fragment_tag_string = "isc_app_over_write_fragment";

    public static final String beacon_home_page_fragment_string = "isc_app_beacon_home_page_fragment";
    public static final String beacon_write_page_fragment_string = "isc_app_beacon_write_fragment";
    public static final String beacon_read_page_fragment_string = "isc_app_beacon_read_fragment";
    public static final String beacon_mode_fragment_string = "isc_app_beacon_mode_fragment";


    public static final String beacon_pin_entry_fragment_string = "isc_app_beacon_pin_dialog";

    public static final String read_card_fragment_string = "isc_app_card_read_fragment";
}
