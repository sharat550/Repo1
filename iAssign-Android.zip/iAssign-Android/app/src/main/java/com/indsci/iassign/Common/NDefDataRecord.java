package com.indsci.iassign.Common;

/**
 * Created by JAgostoni on 7/13/2016.
 */
public interface NDefDataRecord {

    String toNDefString();
}
