package com.indsci.iassign.Common;

import com.indsci.iassign.R;
import java.util.ArrayList;

/**
 * Created by JAgostoni on 7/12/2016.
 */
public enum BeaconAccessLevel {

    LEVEL0("0", R.string.access_level_0),
    LEVEL1("1", R.string.access_level_1),
    LEVEL2("2", R.string.access_level_2),
    LEVEL3("3", R.string.access_level_3),
    LEVEL4("4", R.string.access_level_4),
    LEVEL5("5", R.string.access_level_5),
    LEVEL6("6", R.string.access_level_6),
    LEVEL7("7", R.string.access_level_7),
    LEVEL8("8", R.string.access_level_8),
    LEVEL9("9", R.string.access_level_9),
    LEVELA("A", R.string.access_level_A);

    private String accessLevel;
    private int resourceId;
    BeaconAccessLevel(String accessLevelCode, int id) {
        accessLevel = accessLevelCode;
        resourceId = id;
    }


    @Override
    public String toString() {
        return IAssignApplication.getContext().getString(resourceId);
    }

    public String toValue() { return accessLevel; }

    public static BeaconAccessLevel fromString(String val) {
        for (BeaconAccessLevel v: values()) {
            if (v.toString().equals(val)) {
                return v;
            }
        }
        return null;
    }

    public static ArrayList<String> toIdList() {
        ArrayList<String> _accessValues = new ArrayList<>();
        for (BeaconAccessLevel al : BeaconAccessLevel.values()) {
            _accessValues.add(al.toString());
        }
        return _accessValues;
    }

    public static BeaconAccessLevel fromValue(String accessLevel) {
        for (BeaconAccessLevel v: values()) {
            if(v.accessLevel.equals(accessLevel)) {
                return v;
            }
        }

        return null;
    }
}

