package com.indsci.iassign;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.indsci.iassign.Common.iError;

public class AboutFragment extends Fragment
{
    /* Text view that displays application version*/
    TextView app_version;

    ImageView mFacebook;
    ImageView mTwitter;
    ImageView mLinkdIn;
    ImageView mYoutube;

    public static AboutFragment newInstance()
    {
        //AboutFragment fragment = new AboutFragment();
        return new AboutFragment();
    }

    public AboutFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View about_page_view = inflater.inflate(R.layout.fragment_about, container, false);

        /* Initialize text view present in this fragment to display application version
        * Other information application name, owner, copyright etc is hard coded in xml
        * */
        app_version = (TextView) about_page_view.findViewById(R.id.about_app_version);

        try
        {
            /* Get version name string from package manager*/
            String versionName = getActivity().getPackageManager()
                    .getPackageInfo(getActivity().getPackageName(), 0).versionName;

            /* Display application version name*/
            app_version.setText(getString(R.string.version) + versionName);
        }
        catch (PackageManager.NameNotFoundException ex)
        {
            /* If name not found, display empty version string. No need to throw/display this exception*/
            app_version.setText(getString(R.string.version)+ "-");

            Log.e(iError.App_TAG, ex.toString());
        }
//        catch (Exception ex)
//        {
//            /* Against any other exception just display empty version string. No need to throw/display this exception*/
//            app_version.setText(getString(R.string.version)+"-");
//        }

        /* Select current fragment option in navigation drawer*/
        select_navigation_option();

        TextView privacyLink = (TextView) about_page_view.findViewById(R.id.about_privacy_website);
        if (privacyLink != null) {
            privacyLink.setMovementMethod(LinkMovementMethod.getInstance());
        }

        // Prepare social icons.
        mFacebook = (ImageView) about_page_view.findViewById(R.id.about_us_facebook);
        mFacebook.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    try
                    {
                        getOpenFacebook();
                    }
                    catch (Exception ex)
                    {
                        //Ink.log_about_frag(ex.getMessage());
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {

                }
                else
                {

                }

                return true;
            }
        });

        mTwitter = (ImageView) about_page_view.findViewById(R.id.about_us_twitter);
        mTwitter.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    try
                    {
                        getOpenTwitter();
                    }
                    catch (Exception ex)
                    {
                        //Ink.log_about_frag(ex.getMessage());
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {

                }
                else
                {

                }

                return true;
            }
        });

        mLinkdIn = (ImageView) about_page_view.findViewById(R.id.about_us_linkdin);
        mLinkdIn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    try
                    {
                        getOpenLinkedIn();
                    }
                    catch (Exception ex)
                    {
                        //Ink.log_about_frag(ex.getMessage());
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {

                }
                else
                {

                }

                return true;
            }
        });

        mYoutube = (ImageView) about_page_view.findViewById(R.id.about_us_youtube);
        mYoutube.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    try
                    {
                        getOpenYoutube();
                    }
                    catch (Exception ex)
                    {
                        //Ink.log_about_frag(ex.getMessage());
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {

                }
                else
                {

                }

                return true;
            }
        });

        return about_page_view;
    }

    /**
     * Calls main activity's select page method to select current fragment option under navigation drawer.
     */
    private void select_navigation_option()
    {
        try {
            HomeActivity hActivity = (HomeActivity) getActivity();

            if (hActivity != null) {
                hActivity.select_page(5);
            }
        }
        catch (Exception ex)
        {
            Log.e(iError.App_TAG , ex.toString());
        }
    }

    public void getOpenFacebook() {
        // Industrial Scientific facebook id is 100585036661956
        Intent intent;
        try {
            // Check if FB app is even installed
            getActivity().getPackageManager().getPackageInfo("com.facebook.katana", 0);

            intent =  new Intent(Intent.ACTION_VIEW, Uri.parse("fb://page/100585036661956"));
        } catch (Exception e) {
            intent =  new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/100585036661956"));
        }

        this.startActivity(intent);
    }

    public void getOpenTwitter()
    {
        // Industrial Scientific twitter id is 600957712.

        Intent intent;

        try {
            // get the Twitter app if possible
            getActivity().getPackageManager().getPackageInfo("com.twitter.android", 0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?user_id=600957712"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        } catch (Exception e) {
            // no Twitter app, revert to browser
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/IndSci_Corp"));
        }

        this.startActivity(intent);
    }

    public void getOpenLinkedIn()
    {
        //https://www.linkedin.com/company/industrial-scientific
        try {
            Intent intent;
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.linkedin.com/company/industrial-scientific"));
            startActivity(intent);
        }
        catch (Exception ex)
        {
            //Ink.log_about_frag(ex.getMessage());
        }
    }

    public void getOpenYoutube()
    {
        //http://www.youtube.com/indsci
        try {
            Intent intent;
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/indsci"));
            startActivity(intent);
        }
        catch (Exception ex)
        {
            //Ink.log_about_frag(ex.getMessage());
        }
    }
}