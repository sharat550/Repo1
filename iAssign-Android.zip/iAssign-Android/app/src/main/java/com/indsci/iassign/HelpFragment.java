package com.indsci.iassign;

import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HelpFragment extends Fragment {

    LinearLayout mMain;

    public static HelpFragment newInstance() {
        //HelpFragment fragment = new HelpFragment();
        return new HelpFragment();
    }

    public HelpFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_help, container, false);

        mMain = (LinearLayout) v.findViewById(R.id.help_main_layer);

        AddQuestionAnswers(inflater , "1" , getString(R.string.help_q_1) , getString(R.string.help_q_1_ans));

        AddQuestionAnswers(inflater , "2" , getString(R.string.help_q_2) , getString(R.string.help_q_2_ans));

        AddQuestionAnswers(inflater , "3" , getString(R.string.help_q_3) , getString(R.string.help_q_3_ans));

        AddQuestionAnswers(inflater , "4" , getString(R.string.help_q_4) , getString(R.string.help_q_4_ans));

        AddQuestionAnswers(inflater , "5" , getString(R.string.help_q_5) , getString(R.string.help_q_5_ans));

        AddQuestionAnswers(inflater , "6" , getString(R.string.help_q_6) , getString(R.string.help_q_6_ans));

        AddQuestionAnswers(inflater , "7" , getString(R.string.help_q_7) , getString(R.string.help_q_7_ans));

        select_navigation_option();

        return v;
    }

    private void select_navigation_option() {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if (hActivity != null) {
            hActivity.select_page(9);
        }
    }


    private void AddQuestionAnswers(LayoutInflater inflater , String number, String question, String answer) {
        View v = inflater.inflate(R.layout.help_question_layout, mMain, false);

        TextView mMark = (TextView) v.findViewById(R.id.help_mark);
        TextView mQuestion  = (TextView) v.findViewById(R.id.help_question);
        TextView mAnswer = (TextView) v.findViewById(R.id.help_question_answer);

        mMark.setText(number);
        mQuestion.setText(question);
        mAnswer.setText(answer);

        mMain.addView(v);
    }
}