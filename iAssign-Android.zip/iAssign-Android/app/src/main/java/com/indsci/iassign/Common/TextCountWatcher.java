package com.indsci.iassign.Common;

import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import com.indsci.iassign.R;


/**
 * Created by JAgostoni on 7/13/2016.
 */
public class TextCountWatcher implements TextWatcher {


    private TextView _CountView;
    private int _MaxChars;

    public TextCountWatcher(TextView countView, int maxChars) {
        _CountView = countView;
        _MaxChars = maxChars;
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        int length = editable.length();

        _CountView.setText(length + "/" + String.valueOf(_MaxChars));

        if(length == _MaxChars)
        {
            _CountView.setTextColor(Color.RED);
        }
        else {
            _CountView.setTextColor(_CountView.getResources().getColor(R.color.indsci_green));
        }
    }
}
