package com.indsci.iassign;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BuyIassignFragment extends Fragment {

    LinearLayout mFindDistributorLayer;
    TextView mFindDistributorTextView;

    public static BuyIassignFragment newInstance() {
        BuyIassignFragment fragment = new BuyIassignFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    public BuyIassignFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_buy_tag, container, false);

        mFindDistributorLayer = (LinearLayout) v.findViewById(R.id.find_distributor_layer);
        mFindDistributorTextView = (TextView) v.findViewById(R.id.purchase_text);

        mFindDistributorLayer.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    mFindDistributorTextView.setTextColor(getResources().getColor(R.color.indsci_white));

                    try
                    {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.indsci.com/where-to-buy/"));
                        startActivity(browserIntent);
                    }
                    catch (Exception ex)
                    {
                        Log.e("iAssign" , ex.toString());
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    mFindDistributorTextView.setTextColor(getResources().getColor(R.color.indsci_black));
                }

                return true;
            }
        });

        select_navigation_option();

        return v;

    }

    /*
    **
     */
    private void select_navigation_option()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.select_page(3);
        }
    }
}