package com.indsci.iassign.Common;

import com.indsci.iassign.R;

import java.util.ArrayList;

/**
 * Created by mkloszewski on 8/31/2016.
 */
public enum UserAccessLevel {

    LEVEL0("0",R.string.user_access_level_0),
    LEVEL1("1", R.string.user_access_level_1),
    LEVEL2("2", R.string.user_access_level_2),
    LEVEL3("3", R.string.user_access_level_3),
    LEVEL4("4", R.string.user_access_level_4),
    LEVEL5("5", R.string.user_access_level_5),
    LEVEL6("6", R.string.user_access_level_6),
    LEVEL7("7", R.string.user_access_level_7),
    LEVEL8("8", R.string.user_access_level_8),
    LEVEL9("9", R.string.user_access_level_9),
    LEVELA("A", R.string.user_access_level_A);

    private String accessLevel;
    private int resourceId;
    UserAccessLevel(String accessLevelCode, int id) {
        accessLevel = accessLevelCode;
        resourceId = id;
    }


    @Override
    public String toString() {
        return IAssignApplication.getContext().getString(resourceId);
    }

    public String toValue() { return accessLevel; }

    public static UserAccessLevel fromString(String val) {
        for (UserAccessLevel v: values()) {
            if (v.toString().equals(val)) {
                return v;
            }
        }
        return null;
    }

    public static ArrayList<String> toIdList() {
        ArrayList<String> _accessValues = new ArrayList<>();
        for (UserAccessLevel al : UserAccessLevel.values()) {
            _accessValues.add(al.toString());
        }
        return _accessValues;
    }

    public static UserAccessLevel fromValue(String accessLevel) {
        for (UserAccessLevel v: values()) {
            if(v.accessLevel.equals(accessLevel)) {
                return v;
            }
        }

        return null;
    }

}
