package com.indsci.iassign;

import android.app.Dialog;
import android.app.FragmentManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.view.ViewGroup.LayoutParams;
import android.widget.PopupWindow;

import com.indsci.iassign.Common.FrameNames;
import com.indsci.iassign.Common.NextAction;

public class TagHomePageFragment extends Fragment
{
    private static final String OpenReadTag = "OpenReadTag";

    LinearLayout btnReadTag;
    LinearLayout btnWriteTag;
    LinearLayout btnBuyTags;
    LinearLayout btnBulkWrite;
    Dialog read_dialog;

    LinearLayout layoutOfPopup;
    PopupWindow popupMessage;
    View read_tag_dialog;

    boolean show_read_tag_dialog = false;

    public static TagHomePageFragment newInstance(boolean openreadtag)
    {
        TagHomePageFragment fragment = new TagHomePageFragment();

        Bundle args = new Bundle();

        args.putBoolean(OpenReadTag, openreadtag);

        fragment.setArguments(args);

        return fragment;
    }

    public TagHomePageFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            show_read_tag_dialog = getArguments().getBoolean(OpenReadTag);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View home_page_view = inflater.inflate(R.layout.fragment_tag_home_page, container, false);

        initialize_view(home_page_view);

        initialize_read_dialog();

        select_navigation_option();

        if(show_read_tag_dialog)
        {
            if(!get_NFC_state())
            {
                display_error_message(getString(R.string.nfc_disabled), NextAction.Enable_NFC);
            }
            else {
                display_read_tag_dialog(home_page_view);
            }
        }

        return home_page_view;
    }

    @Override
    public void onStop ()
    {
        super.onStop();

        if(read_dialog != null) {
            if (read_dialog.isShowing()) {
                read_dialog.dismiss();
            }
        }
    }

    public void initialize_view(View v)
    {
        read_tag_dialog = View.inflate(getActivity(), R.layout.readtag_dialog, null);

        btnReadTag = (LinearLayout) v.findViewById(R.id.btn_home_read_tag);
        btnReadTag.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    btnReadTag.setBackgroundColor(getResources().getColor(R.color.indsci_white));
                    if(!get_NFC_state())
                    {
                        display_error_message(getString(R.string.nfc_disabled),NextAction.Enable_NFC);
                    }
                    else {
                        display_read_tag_dialog(v);
                    }
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    btnReadTag.setBackgroundColor(getResources().getColor(R.color.indsci_white_shade));
                }
                else
                {
                    btnReadTag.setBackgroundColor(getResources().getColor(R.color.indsci_white));
                }

                return true;
            }
        });

        btnWriteTag = (LinearLayout) v.findViewById(R.id.btn_home_write_tag);

        btnWriteTag.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    btnWriteTag.setBackgroundColor(getResources().getColor(R.color.indsci_white));

                    // update the main content by replacing fragments
                    FragmentManager fragmentManager = getFragmentManager();

                    fragmentManager.beginTransaction()
                            .replace(R.id.container, WriteTagFragment.newInstance(null, false), FrameNames.write_tag_fragment_tag_string)
                            .addToBackStack(FrameNames.write_tag_fragment_tag_string)
                            .commit();
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    btnWriteTag.setBackgroundColor(getResources().getColor(R.color.indsci_white_shade));
                }
                else
                {
                    btnWriteTag.setBackgroundColor(getResources().getColor(R.color.indsci_white));
                }

                return true;
            }
        });

        btnBulkWrite = (LinearLayout) v.findViewById(R.id.btn_home_write_bulk);
        btnBulkWrite.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP)
                {
                    btnBulkWrite.setBackgroundColor(getResources().getColor(R.color.indsci_white));

                    // update the main content by replacing fragments
                    FragmentManager fragmentManager = getFragmentManager();

                    fragmentManager.beginTransaction()
                            .replace(R.id.container, BulkWriteFragment.newInstance() , FrameNames.Bulk_Write_fragment_tag_string)
                            .addToBackStack(FrameNames.Bulk_Write_fragment_tag_string)
                            .commit();
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    btnBulkWrite.setBackgroundColor(getResources().getColor(R.color.indsci_white_shade));
                }
                else
                {
                    btnBulkWrite.setBackgroundColor(getResources().getColor(R.color.indsci_white));
                }

                return true;
            }
        });

        btnBuyTags = (LinearLayout) v.findViewById(R.id.btn_home_buy_tags);
        btnBuyTags.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    btnBuyTags.setBackgroundColor(getResources().getColor(R.color.indsci_white));

                    // update the main content by replacing fragments
                    FragmentManager fragmentManager = getFragmentManager();

                    fragmentManager.beginTransaction()
                            .replace(R.id.container, BuyIassignFragment.newInstance(), FrameNames.buy_iassign_fragment_string)
                            .addToBackStack(FrameNames.buy_iassign_fragment_string)
                            .commit();
                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btnBuyTags.setBackgroundColor(getResources().getColor(R.color.indsci_white_shade));
                }
                else
                {
                    btnBuyTags.setBackgroundColor(getResources().getColor(R.color.indsci_white));
                }

                return true;
            }
        });
    }

    private void initialize_read_dialog()
    {
        popupMessage = new PopupWindow(layoutOfPopup, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        popupMessage.setContentView(layoutOfPopup);
    }

    private void display_read_tag_dialog(View v)
    {
        //if (v.getId() == R.id.btn_home_read_tag)
        //{
            // Create custom dialog object
            read_dialog = new Dialog(getActivity());

            // Include dialog.xml file
            read_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            read_dialog.setContentView(R.layout.readtag_dialog);
            read_dialog.show();

            WindowManager.LayoutParams lp = read_dialog.getWindow().getAttributes();
            lp.dimAmount = 0.8f;
            read_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        read_dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        //}
        //else
        //{
        //    popupMessage.dismiss();
        //}
    }

    private void select_navigation_option()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.select_page(0);
        }
    }

    private boolean get_NFC_state()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            return hActivity.getNFC_state();
        }

        return false;
    }

    private void display_error_message(String msg, NextAction _next)
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.display_error_dialog(msg, _next, true);
        }
    }

    public void dismiss_read_tag_dialog() {
        if (read_dialog != null) {
            read_dialog.dismiss();
        }
        read_dialog = null;

    }
}