package com.indsci.iassign;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.app.Fragment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.Locale;

public class LanguageFragment extends Fragment
{
    private static final String PREF_USER_Prefered_Languages = "iAssignLanguage";

    private RadioGroup mRadios;

    public static LanguageFragment newInstance()
    {
        //LanguageFragment fragment = new LanguageFragment();
        return new LanguageFragment();
    }

    public LanguageFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        final View language_page_view = inflater.inflate(R.layout.fragment_language, container, false);

        mRadios = (RadioGroup) language_page_view.findViewById(R.id.radiogroup);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());

        int LanguageIndex = sp.getInt(PREF_USER_Prefered_Languages, 0);

        if(LanguageIndex == 0) {
            mRadios.check(R.id.radioButton_en);
        }
        else if (LanguageIndex == 1)
        {
            mRadios.check(R.id.radioButton_fr);
        }
        else if (LanguageIndex == 2)
        {
            mRadios.check(R.id.radioButton_de);
        }
        else if(LanguageIndex == 3)
        {
            mRadios.check(R.id.radioButton_es);
        }


        mRadios.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                try {
                    if (checkedId == R.id.radioButton_en) {
                        change_language(language_page_view, 0);
                    } else if (checkedId == R.id.radioButton_fr) {
                        change_language(language_page_view, 1);
                    } else if (checkedId == R.id.radioButton_de) {
                        change_language(language_page_view, 2);
                    } else if (checkedId == R.id.radioButton_es) {
                        change_language(language_page_view, 3);
                    } else {
                        change_language(language_page_view, 0);
                    }

                    HomeActivity home = (HomeActivity) getActivity();
                    home.refresh();
                } catch (Exception ex) {
                    Log.e("iAssign", ex.toString());
                }
            }
        });

        select_navigation_option();

        return language_page_view;
    }


    private void change_language(View v , int position)
    {
        Locale mLocale;
        Configuration config;

        try
        {
            switch (position)
            {
                case 0:
                    mLocale = new Locale("en");
                    break;
                case 1:
                    mLocale = new Locale("fr");
                    break;
                case 2:
                    mLocale = new Locale("de");
                    break;
                case 3:
                    mLocale = new Locale("es");
                    break;
                default:
                    mLocale = new Locale("en");
                    break;
            }

            Locale.setDefault(mLocale);

            config = v.getContext().getResources().getConfiguration();

            if (!config.locale.equals(mLocale))
            {
                config.locale = mLocale;
                v.getContext().getResources().updateConfiguration(config, null);
            }

            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());

            sp.edit().putInt(PREF_USER_Prefered_Languages , position).apply();
        }
        catch (Exception ex)
        {
            Log.e("iAssign", ex.toString());
        }
    }

    private void select_navigation_option()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.select_page(7);
        }
    }
}