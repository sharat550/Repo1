package com.indsci.iassign;

import android.app.*;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NfcA;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.support.v4.widget.DrawerLayout;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.indsci.iassign.Beacons.BeaconHomePageFragment;
import com.indsci.iassign.Beacons.BeaconModeFragment;
import com.indsci.iassign.Beacons.BeaconReadFragment;
import com.indsci.iassign.Cards.CardReadFragment;
import com.indsci.iassign.Common.*;
import com.indsci.iassign.Engine.MFUltralight_C_Library;
import com.indsci.iassign.Engine.NTag203x_Library;
import com.indsci.iassign.Engine.NTag213215216_Library;
import com.indsci.iassign.Engine.NTagI2CPlus_Library;
import com.indsci.iassign.Engine.NTagI2C_Library;

//import com.nxp.nfclib.Interface.NxpNfcLib;
//import com.nxp.nfclib.Interface.Nxpnfclibcallback;
import com.nxp.nfclib.NxpNfcLib;
import com.nxp.nfclib.Nxpnfclibcallback;
//import com.nxp.nfclib.desfire.DESFire;
import com.nxp.nfclib.exceptions.CloneDetectedException;
import com.nxp.nfclib.exceptions.SmartCardException;
import com.nxp.nfclib.keystore.common.IKeyConstants;
import com.nxp.nfclib.keystore.common.IKeyStore;
import com.nxp.nfclib.keystore.common.KeyStoreFactory;
import com.nxp.nfclib.ntag.INTAGI2Cplus;
import com.nxp.nfclib.ntag.INTag203x;
import com.nxp.nfclib.ntag.INTag213215216;
import com.nxp.nfclib.ntag.INTagI2C;
//import com.nxp.nfclib.plus.Plus;
import com.nxp.nfclib.ultralight.IUltralightC;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import net.hockeyapp.android.*;
import net.hockeyapp.android.metrics.MetricsManager;

public class HomeActivity extends ActionBarActivity
        implements NavigationDrawerFragment.NavigationDrawerCallbacks
{

    /**
     * Fragment managing the behaviors, interactions and presentation of the navigation drawer.
     */
    private NavigationDrawerFragment mNavigationDrawerFragment;

//    /**
//     * Used to store the last screen title.
//     */
//    private CharSequence mTitle;

    /** Application Tag. */
    static final String TAG = "iAssign";

    /** Create lib lite instance. */
    private NxpNfcLib libInstance = null;

    /** key store. */
    private IKeyStore ks = null;

    private byte[] deviceSerial;
    private byte[] deviceUnlockPIN;

    /** NFC Data Type used to decide if data is parsable or not.*/
    public static final String MIME_TEXT_PLAIN = "text/plain";

    /** Application own NFC adapter that reads NFC tags without using MIFARE SDK.
     * Its pretty fast while reading tags.
     * Don't required tag type detection
     * */
    private NfcAdapter mNfcAdapter;

    /**
     * Package Key. Required for MiFARE SDK to register our application with it.
     * Key generated at https://inspire.nxp.com/mifare/myapp.html
     * Package Name : com.indsci.iassign
     * Application Name : iassign
     */
    static String packageKey = "cf232f7ca7bd2a3d69a4e20b5ed67072";

    /**
     * Library instance that will handle MiFARE Ultralight C NFC tags;
     */
    public MFUltralight_C_Library _MFUltralight_c_library =  null;

    /**
     * Library instance that will handle NTAG203x NFC tags
     */
    public NTag203x_Library _NTag203x_library = null;

    /**
     * Library instance that will handle NTAG213215216 NFC tags
     */
    public NTag213215216_Library _NTag213215216_library = null;

    /**
     * Library instance that will handle NTAGI2C NFC tags
     */
    public NTagI2C_Library _NTagI2C_library = null;

    /**
     * Library instance that will handle NTAGI2C_PLUS NFC tags
     */
    public NTagI2CPlus_Library _NTagI2C_Plus_library = null;

    /**
     * Write Tag fragment and Bulk write tag fragment will set this flag to allow main activity write operation on onNewIntent
     */
    public boolean Ready_To_Write_Flag = false;

    public boolean Mode_Read_Flag;
    public boolean Mode_Write_Flag;
    public boolean Unlocking_Beacon_Flag;
//    /**
//     * KEY_APP_MASTER key used for encrypt data.
//     */
//    private static final String KEY_APP_MASTER = "This is my key  ";

    /**
     * Default key with Value FF.
     */
    public static final byte[] KEY_DEFAULT_FF = { (byte) 0xFF, (byte) 0xFF,
            (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF };
//    /**
//     * Default key with Value Zeros.
//     */
//    public static final byte[] KEY_DEFAULT_00 = { (byte) 0x00, (byte) 0x00,
//            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00 };
//
//    /** Default key. */
//    public static final byte[] KEY_DEFAULT_AA = { (byte) 0xAA, (byte) 0xAA,
//            (byte) 0xAA, (byte) 0xAA, (byte) 0xAA, (byte) 0xAA };

    /**
     * 16 bytes AES128 Key.
     */
    public static final byte[] KEY_AES128 = { (byte) 0xFF, (byte) 0xFF,
            (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF,
            (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF,
            (byte) 0xFF, (byte) 0xFF, (byte) 0xFF, (byte) 0xFF };

//    public static final byte[] DEFAULT_KEY_AES128 = { (byte) 0x00, (byte) 0x00,
//            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
//            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
//            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00 };

    /**
     * 16 bytes 2KTDES Key.
     */
    public static final byte[] KEY_2KTDES = { (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00 };

    /**
     * 16 bytes 2KTDES_ULC Key.
     */
    public static final byte[] KEY_2KTDES_ULC = { (byte) 0x49, (byte) 0x45,
            (byte) 0x4D, (byte) 0x4B, (byte) 0x41, (byte) 0x45, (byte) 0x52,
            (byte) 0x42, (byte) 0x21, (byte) 0x4E, (byte) 0x41, (byte) 0x43,
            (byte) 0x55, (byte) 0x4F, (byte) 0x59, (byte) 0x46 };

//    /**
//     * 16 bytes 2KTDES_DESFIRE Key.
//     */
//    public static final byte[] KEY_2KTDES_DESFIRE = { (byte) 0x00, (byte) 0x00,
//            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
//            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,
//            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00 };

    /**
     * Dialog instance displayed when data is ready to be written on next NFC tap
     */
    public Dialog writing_dialog;

    /**
     * Dialog instance displayed when data is successfully written
     */
    public Dialog write_success_dialog;

    /**
     * Dialog instance displayed when some error occurs.
     */
    public Dialog error_dialog;

    public Dialog read_dialog;

    /**
     * Dialog instance displayed when not-supported tag type is detected.
     *
     * This list is available under #TagTypes
     */
    public Dialog invalid_tag_type_dialog;


    /**
     *  Replaces mUser and mSite for refactoring
     */
    public NDefDataRecord mCurrentTagRecord;


    /**
     * Stores current lock state of tag displayed/written
     */
    public Boolean mLockTag;

    public String mLockPIN;

    /**
     * Flag used by main activity to continue read when no write operation is pending
     */
    public boolean read_tag = true;

    /**
     * List that stores bulk write list records (user,site pairs).
     */
    public List<TagDataRecord> Bulk_Write_records = null;

    public int total_bulk_records = 0;
    public int current_bulk_record_number = 0;
    public int current_bulk_record_id = 0;

    private static final String PREF_USER_ACCEPTED_EULA = "UserAcceptedEULA";
    private static final String PREF_USER_Prefered_Language = "iAssignLanguage";
    Dialog eula_dialog;
    boolean mUserAcceptedEULA = false;

    /**
     * Stores current tag type on onNewIntent
     */
    public TagType _current_tag_type = TagType.Unknown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /* Initialize the library and register to this activity */
        initializeLibrary();


        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(HomeActivity.this);
        mUserAcceptedEULA = sp.getBoolean(PREF_USER_ACCEPTED_EULA, false);

        int LanguageIndex = sp.getInt(PREF_USER_Prefered_Language, -1);

        change_language(LanguageIndex);

        setContentView(R.layout.activity_home);

        if(!mUserAcceptedEULA) {
            show_EULA();
        }

        /* Initialize the navigation drawer fragment*/
        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);

//        /* Gets title*/
//        mTitle = getTitle();

        // Set up the drawer.
        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));

        /* Sets action bar custom view and background*/
        restoreActionBar();

        /* Initialize bulk write records list.*/
        Bulk_Write_records = new ArrayList<>();

        /* Initialize local NFC adapter- will be majorly used for reading tags.
        * For writing tags, MIFARE SDK will be used.
        * */
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);

        if (mNfcAdapter == null) {
            // Stop here, we definitely need NFC
            // Send finish code.
            display_error_dialog(getString(R.string.nfc_not_supported), NextAction.Finish, true);
        }
        else {
            if (!mNfcAdapter.isEnabled()) {
                display_error_dialog(getString(R.string.nfc_disabled), NextAction.Enable_NFC, true);
            }

            if (android.os.Build.VERSION.SDK_INT >= 19) {
                mNfcAdapter.enableReaderMode(this, new NfcAdapter.ReaderCallback() {
                    @Override
                    public void onTagDiscovered(Tag tag) {

                        final Tag discovered_tag = tag;

                        HomeActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                if (read_dialog != null) {
                                    if (read_dialog.isShowing()) {
                                        read_dialog.dismiss();
                                    }
                                }

                                //Your code to run in GUI thread here
                                Intent new_intent = new Intent();

                                new_intent.setAction(NfcAdapter.ACTION_TECH_DISCOVERED);

                                new_intent.putExtra(NfcAdapter.EXTRA_TAG, discovered_tag);

                                try {
                                    libInstance.filterIntent(new_intent, callback);

                                    read_tag = nfc_intent_fragment_logic();

                            /* If no write operation is waiting for new Intent. Go Read*/
                                    if (read_tag) {

                                        String[] techList = discovered_tag.getTechList();
                                        String searchedTech = Ndef.class.getName();

                                        boolean tech_matched = false;

                                        for (String tech : techList) {
                                            if (searchedTech.equals(tech)) {
                                                new NdefReaderTask().execute(discovered_tag);
                                                tech_matched = true;
                                                break;
                                            }
                                        }

                                        if (!tech_matched) {
                                            display_error_dialog(getString(R.string.empty_tag), NextAction.Unknown, true);
                                        } else {

                                        }
                                    }
                                }
                                catch (CloneDetectedException ex)
                                {
                                    ex.printStackTrace();
                                }
                            }//public void run() {
                        });

                    }
                }, NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS, null);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();

            // clear FLAG_TRANSLUCENT_STATUS flag:
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

            // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

            // finally change the color
            window.setStatusBarColor(getResources().getColor(R.color.indsci_navyed));

            window.setNavigationBarColor(getResources().getColor(R.color.indsci_navyed));
        }


        // HockeyApp
        checkForUpdates();
        MetricsManager.register(this, getApplication());
    }

    public void change_language(int position)
    {
        Locale mLocale;
        Configuration config;
        boolean mConfigChange = false;

        try
        {
            switch (position)
            {
                case -1:
                    // Check system locale. For first time only.
                    String system_locale = Locale.getDefault().getDisplayLanguage();
                    SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(HomeActivity.this);

                    if(system_locale.equals(Locale.FRENCH.getDisplayName())) {
                        mLocale = new Locale("fr");
                        sp.edit().putInt(PREF_USER_Prefered_Language, 1 ).apply();
                    }
                    else if (system_locale.equals(Locale.GERMAN.getDisplayName()))
                    {
                        mLocale = new Locale("de");
                        sp.edit().putInt(PREF_USER_Prefered_Language, 2).apply();
                    }
                    else if (system_locale.equals("español"))
                    {
                        mLocale = new Locale("es");
                        sp.edit().putInt(PREF_USER_Prefered_Language, 3).apply();
                    }
                    else
                    {
                        mLocale = new Locale("en");
                        sp.edit().putInt(PREF_USER_Prefered_Language, 0).apply();
                    }

                    mConfigChange = true;
                    break;
                case 0:
                    mLocale = new Locale("en");
                    break;
                case 1:
                    mLocale = new Locale("fr");
                    break;
                case 2:
                    mLocale = new Locale("de");
                    break;
                case 3:
                    mLocale = new Locale("es");
                    break;
                default:
                    mLocale = new Locale("en");
                    break;
            }

            config = getApplicationContext().getResources().getConfiguration();

            Locale.setDefault(mLocale);

            if (!config.locale.equals(mLocale))
            {
                config.locale = mLocale;
                getApplicationContext().getResources().updateConfiguration(config, null);

                if(mConfigChange) {
                    refresh();
                }
            }
        }
        catch (Exception ex)
        {
            Log.e(TAG , ex.toString());
        }
    }

    public void refresh() {
        finish();
        Intent myIntent = new Intent(HomeActivity.this, HomeActivity.class);
        startActivity(myIntent);
    }


    /**
     * Initialize NXP Semiconductor MiFARE SDK Library instance
     */
    private void initializeLibrary() {
        libInstance = NxpNfcLib.getInstance();

        libInstance.registerActivity(this, packageKey);

        try {

			/* Initialize the keystore and load the key */
            ks = KeyStoreFactory.getInstance().getSoftwareKeyStore();

			/* MIFARE classic card set the key. */
            ks.formatKeyEntry(0, IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_MIFARE);
            ks.setKey(0, (byte) 0,
                    IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_MIFARE,
                    KEY_DEFAULT_FF);

			/* set the key. */
            ks.formatKeyEntry(1, IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_AES128);
            ks.setKey(1, (byte) 0,
                    IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_AES128, KEY_AES128);

			/* MIFARE DESFire card set the key. */
            ks.formatKeyEntry(2, IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_2K3DES);
            ks.setKey(2, (byte) 0,
                    IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_2K3DES, KEY_2KTDES);

			/* MIFARE Plus */

            ks.formatKeyEntry(3, IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_AES128);
            ks.setKey(3, (byte) 0,
                    IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_AES128, KEY_AES128);

			/*
			 * MIFARE ULtralight C key should be store into a software keystore.
			 */
            ks.formatKeyEntry(4, IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_2K3DES);
            ks.setKey(4, (byte) 0,
                    IKeyConstants.KeyType.KEYSTORE_KEY_TYPE_2K3DES,
                    KEY_2KTDES_ULC);
        }
        catch (SmartCardException e)
        {
            e.printStackTrace();
        }

        libInstance.loadKeyStore(ks);

        // Registering the activity for the NFC tag detection mode.
        /* public void setNfcControllerMode(int presenceCheckDelay,
                        Inxpnfclibcallback callback)

        Limit the NFC controller to reader mode while this Activity is in the foreground.
        In this mode the NFC controller will only act as an NFC tag reader/writer, thus disabling any peer-to-peer (Android Beam)
        and card-emulation modes of the NFC adapter on this device. Polling Technology Type A and V is supported.

        Parameters:
        presenceCheckDelay - Delay in milliseconds between successive presence check.
        callback - Implemented call back interface.*/

//        if(android.os.Build.VERSION.SDK_INT >= 19) {
//            try {
//                libInstance.setNfcControllerMode(1000, callback);
//            } catch (SmartCardException e) {
//                e.printStackTrace();
//            }
//        }
    }

    @Override
    public void onNavigationDrawerItemSelected(int position)
    {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getFragmentManager();

        // Get current focused view
        View focus = getCurrentFocus();

        // Hide soft keyboard if visible.
        if (focus != null) {
            hiddenKeyboard(focus);
        }

        switch (position) {
            case 0: // Home
                fragmentManager.beginTransaction()
                        .replace(R.id.container, HomePageFragment.newInstance() , FrameNames.home_fragment_tag_string)
                        .addToBackStack(FrameNames.home_fragment_tag_string)
                        .commit();
                break;
            case 1: // Read Tag
//                fragmentManager.beginTransaction()
//                        .replace(R.id.container, ReadTagFragment.newInstance(null), FrameNames.read_tag_fragment_tag_string)
//                        .addToBackStack(null)
//                        .commit();
                fragmentManager.beginTransaction()
                        .replace(R.id.container, TagHomePageFragment.newInstance(true) , FrameNames.tag_home_fragment_tag_string)
                        .addToBackStack(FrameNames.tag_home_fragment_tag_string)
                        .commit();
                break;
            case 2: // Write Tag
                fragmentManager.beginTransaction()
                        .replace(R.id.container, WriteTagFragment.newInstance(null , false) , FrameNames.write_tag_fragment_tag_string)
                        .addToBackStack(FrameNames.write_tag_fragment_tag_string)
                        .commit();
                break;
            case 3: // Buy iAssign
                fragmentManager.beginTransaction()
                        .replace(R.id.container, BuyIassignFragment.newInstance(), FrameNames.buy_iassign_fragment_string)
                        .addToBackStack(FrameNames.buy_iassign_fragment_string)
                        .commit();
                break;
            case 4: // Bulk Write*
                fragmentManager.beginTransaction()
                        .replace(R.id.container, BulkWriteFragment.newInstance(), FrameNames.Bulk_Write_fragment_tag_string)
                        .addToBackStack(FrameNames.Bulk_Write_fragment_tag_string)
                        .commit();
                break;
            case 5: // About
                fragmentManager.beginTransaction()
                        .replace(R.id.container, AboutFragment.newInstance(), FrameNames.about_fragment_tag_string)
                        .addToBackStack(FrameNames.about_fragment_tag_string)
                        .commit();
                break;
            case 6: // Legal
                fragmentManager.beginTransaction()
                        .replace(R.id.container, LegalFragment.newInstance() , FrameNames.legal_fragment_tag_string)
                        .addToBackStack(FrameNames.legal_fragment_tag_string)
                        .commit();
                break;
            case 7: // Language
                fragmentManager.beginTransaction()
                        .replace(R.id.container, LanguageFragment.newInstance(), FrameNames.language_fragment_tag_string)
                        .addToBackStack(FrameNames.language_fragment_tag_string)
                        .commit();
                break;
            case 8: // Feedback
                fragmentManager.beginTransaction()
                        .replace(R.id.container, FeedbackFragment.newInstance(), FrameNames.feedback_fragment_tag_string)
                        .addToBackStack(FrameNames.feedback_fragment_tag_string)
                        .commit();
                break;
            case 9: // Help
                fragmentManager.beginTransaction()
                        .replace(R.id.container, HelpFragment.newInstance(), FrameNames.help_fragment_tag_string)
                        .addToBackStack(FrameNames.help_fragment_tag_string)
                        .commit();
                break;
            case 10: // Beacon
                fragmentManager.beginTransaction()
                        .replace(R.id.container, BeaconHomePageFragment.newInstance(), FrameNames.beacon_home_page_fragment_string)
                        .addToBackStack(FrameNames.beacon_home_page_fragment_string)
                        .commit();
                break;
            case 11: // Tags
                fragmentManager.beginTransaction()
                        .replace(R.id.container, TagHomePageFragment.newInstance(false), FrameNames.tag_home_fragment_tag_string)
                        .addToBackStack(FrameNames.tag_home_fragment_tag_string)
                        .commit();
                break;
            case 12: // Cards
            default:
                display_read_card_dialog();
                break;
        }
    }

    /**
     * Hides soft keyboard from screen. Navigation drawer uses it before every selection.
     * @param v current focused view
     */
    private void hiddenKeyboard(View v)
    {
        InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        keyboard.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    /**
     * sets Action Bar custom view and background.
     */
    public void restoreActionBar()
    {
        ActionBar actionBar = getSupportActionBar();
        ColorDrawable cd = new ColorDrawable(getResources().getColor(R.color.indsci_navy));
        actionBar.setBackgroundDrawable(cd);
        actionBar.setCustomView(R.layout.title_bar_layout);
        actionBar.setDisplayShowCustomEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed()
    {
        /* Get total fragment entries available in stack */
        int entries = getFragmentManager().getBackStackEntryCount();

        /* If entries are greater than that means we are on some where but not on home page*/
        if (entries > 1)
        {
            /* Home page is also a fragment so we have to go back to it instead of getting out of application.
            * get id for entry at 2nd location instead of 1st location in stack.*/
            int first_entry_id = getFragmentManager().getBackStackEntryAt(1).getId();

            /* Go to home page*/
            getFragmentManager().popBackStack(first_entry_id,FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        else
        {
            /* Single entry means we are on home page. Just get out of application in this case*/
            super.onBackPressed();
        }
    }

    @Override
    public void onPause() {

        if(mNfcAdapter != null) {
//            if(android.os.Build.VERSION.SDK_INT >= 19) {
//                mNfcAdapter.disableReaderMode(this);
//            }

            stopForegroundDispatch(this, mNfcAdapter);
        }
        super.onPause();

        //HockeyApp
        unregisterManagers();

         /* Stop Foreground Dispatch to stop receiving intents on new NFC tag discovery*/
        //libInstance.stopForeGroundDispatch();
    }

    @Override
    public void onResume() {
        super.onResume();

        /* Start NXP Semiconductor MiFARE SDK library instance Foreground dispatch to receive new
        intents on NFC tag discovery */
        //libInstance.startForeGroundDispatch();
        if(mNfcAdapter != null) {
            setupForegroundDispatch(this, mNfcAdapter);


            // HockeyApp
            checkForCrashes();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        // HockeyApp
        unregisterManagers();
    }

    /**
     * @param activity The corresponding {@link android.app.Activity} requesting the foreground dispatch.
     * @param adapter The {@link NfcAdapter} used for the foreground dispatch.
     */
    public static void setupForegroundDispatch(final Activity activity, NfcAdapter adapter) {
        final Intent intent = new Intent(activity.getApplicationContext(), activity.getClass());
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        final PendingIntent pendingIntent = PendingIntent.getActivity(activity.getApplicationContext(), 0, intent, 0);

        IntentFilter[] filters = new IntentFilter[3];
        String[][] techList = new String[][]{};

        // Notice that this is the same filter as in our manifest.
        filters[0] = new IntentFilter();
        filters[0].addAction(NfcAdapter.ACTION_NDEF_DISCOVERED);
        filters[0].addCategory(Intent.CATEGORY_DEFAULT);

        filters[1] = new IntentFilter();
        filters[1].addAction(NfcAdapter.ACTION_TECH_DISCOVERED);

        filters[2] = new IntentFilter();
        filters[2].addAction(NfcAdapter.ACTION_TAG_DISCOVERED);

        try
        {
            filters[0].addDataType(MIME_TEXT_PLAIN);
        }
        catch (IntentFilter.MalformedMimeTypeException e)
        {
            throw new RuntimeException("Check your mime type.");
        }

        adapter.enableForegroundDispatch(activity, pendingIntent, filters, techList);
    }

    /**
     * @param activity T
     * @param adapter The {@link NfcAdapter} used for the foreground dispatch.
     */
    public static void stopForegroundDispatch(final Activity activity, NfcAdapter adapter) {
        adapter.disableForegroundDispatch(activity);
    }

    @Override
    public void onStart()
    {
        super.onStart();
    }

    /**
     * (non-Javadoc).
     *
     * @see android.app.Activity#onNewIntent(android.content.Intent)
     *
     * @param intent
     *            NFC intent from the android framework.
     */
    protected void onNewIntent(final Intent intent)
    {
        if(read_dialog != null)
        {
            if(read_dialog.isShowing())
            {
                read_dialog.dismiss();
            }
        }

        try {
        /* Filter intent on new Intent. Receive the intent in NXP Semiconductor MiFARE SDK Library instance*/
            libInstance.filterIntent(intent, callback);

            read_tag = nfc_intent_fragment_logic();

            /* If no write operation is waiting for new Intent. Go Read*/
            if (read_tag) {
                handleIntent(intent);
            }
            //super.onNewIntent(intent);
        }
        catch (CloneDetectedException e)
        {
            e.printStackTrace();
        }
    }

    private void handleIntent(Intent intent) {
        String action = intent.getAction();
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {

            String type = intent.getType();
            if (MIME_TEXT_PLAIN.equals(type)) {

                Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
                new NdefReaderTask().execute(tag);

            } else {
                Log.d(TAG, "Wrong mime type: " + type);
            }
        } else if (NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)) {

            // In case we would still use the Tech Discovered Intent
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            String[] techList = tag.getTechList();
            String searchedTech = Ndef.class.getName();

            for (String tech : techList) {
                if (searchedTech.equals(tech)) {
                    new NdefReaderTask().execute(tag);
                    break;
                }
            }
        }
        else if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action))
        {
            // In case we would still use the Tech Discovered Intent
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            String[] techList = tag.getTechList();
            String searchedTech = Ndef.class.getName();

            boolean tech_matched = false;

            for (String tech : techList) {
                if (searchedTech.equals(tech)) {
                    new NdefReaderTask().execute(tag);
                    tech_matched = true;
                    break;
                }
            }

            if(!tech_matched)
            {
                display_error_dialog(getString(R.string.empty_tag) , NextAction.Unknown, true);
            }
        }
    }

    /**
     * Background task for reading the data. Do not block the UI thread while reading.
     *
     * @author Ralf Wondratschek
     *
     */
    class NdefReaderTask extends AsyncTask<Tag, Void, String> {

        boolean is_locked = false;

        @Override
        protected String doInBackground(Tag... params) {
            Tag tag = params[0];

            is_locked = false;

            // Instantiate instances of NfcA and Ndef
            Ndef ndef = Ndef.get(tag);
            NfcA nfca = NfcA.get(tag);

            // Read the serial number & lock code via NfcA
            try {
              nfca.connect();
                // Try to retrieve serial number
                byte[] input = new byte[] {(byte)0x30, (byte)0xC5};
                byte[] serialNo = nfca.transceive(input);

                // Try to retrieve device lock code
                byte[] pinRetrieval = new byte[] {(byte)0x30, (byte)0xDD };
                byte[] pin = nfca.transceive(pinRetrieval);

                nfca.close();

                deviceUnlockPIN = pin;
                deviceSerial = serialNo;
            } catch (Exception e) {
                Log.e("1", "Serial read failed - not a beacon?");
            }

            is_locked = !ndef.isWritable();

            NdefMessage ndefMessage = ndef.getCachedNdefMessage();


            if(ndefMessage == null)
                return null;

            NdefRecord[] records = ndefMessage.getRecords();

            for (NdefRecord ndefRecord : records) {
                if (ndefRecord.getTnf() == NdefRecord.TNF_WELL_KNOWN && Arrays.equals(ndefRecord.getType(), NdefRecord.RTD_TEXT)) {
                    try {
                        return readText(ndefRecord);
                    } catch (UnsupportedEncodingException e) {
                        Log.e("1", "Unsupported Encoding", e);
                    }
                }
            }

            return null;
        }

        private String readText(NdefRecord record) throws UnsupportedEncodingException {
        /*
         * See NFC forum specification for "Text Record Type Definition" at 3.2.1
         *
         * http://www.nfc-forum.org/specs/
         *
         * bit_7 defines encoding
         * bit_6 reserved for future use, must be 0
         * bit_5..0 length of IANA language code
         */
            if(record == null)
                return null;

            byte[] payload = record.getPayload();

            // Get the Text Encoding
            String textEncoding = (payload[0] & 128) == 0 ? "UTF-8" : "UTF-16";

            // Get the Language Code
            int languageCodeLength = payload[0] & 0x63;

            // String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");
            // e.g. "en"

            // Get the Text
            return new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                detectTagAndLaunch(result, is_locked);
            } else
            {
                display_error_dialog(getString(R.string.empty_tag) , NextAction.Unknown, true);
            }
        }
    }

    private void detectTagAndLaunch(String payload, boolean is_locked) {
        // Get field array
        String[] lines = payload.split("\n");
        List<String> fields = Arrays.asList(lines[0].split(("#")));

        if(payload.contains("Mode:")) {
            // Likely a Beacon
            BeaconDataRecord record = BeaconDataRecord.FromNDefFields(fields, is_locked);

            if(record != null && Mode_Read_Flag == false) {
                notify_user();

                Fragment readBeacon = BeaconReadFragment.newInstance(record, deviceSerial, deviceUnlockPIN);
                PushFragment(getFragmentManager(), readBeacon, FrameNames.beacon_read_page_fragment_string);


            }
            else if (record != null && Mode_Read_Flag == true) {
                notify_user();

                Fragment beaconMode = BeaconModeFragment.newInstance(record);
                Mode_Read_Flag = false;
                PushFragment(getFragmentManager(), beaconMode, FrameNames.beacon_mode_fragment_string);
            }
            else {
                display_error_dialog(getString(R.string.empty_tag) , NextAction.Unknown, true);
            }
        }
        else if (payload.contains("WULCK:")) {
            // Likely an activation card
            CardDataRecord record = new CardDataRecord(payload);

            Fragment readCard = CardReadFragment.newInstance(record);
            PushFragment(getFragmentManager(), readCard, FrameNames.read_card_fragment_string);
        }
        else {
            // Likely a Tag


            TagDataRecord dRecord = get_user_site(fields, is_locked);

            if(dRecord != null) {

                notify_user();

                startReadTag_Fragment(dRecord);
            }
            else
            {
                display_error_dialog(getString(R.string.empty_tag) , NextAction.Unknown, true);
            }

        }

    }

    private TagDataRecord get_user_site(List<String> fields , boolean is_locked)
    {
        return TagDataRecord.FromNDefFields(fields, is_locked);
    }

    /**
     * Nxpnfccallback card detected.
     */
    Nxpnfclibcallback callback = new Nxpnfclibcallback()
    {
        /*
        * NXP Semiconductor MiFARE SDK Library
        * callback that handles MiFARE Ultralight C type NFC tags
        * */
        @Override
        public void onUltraLightCCardDetected(IUltralightC ulC)
        {
            /* Store current detected NFC tag type */
            _current_tag_type = TagType.MiFareUltraLightC;

            /* Initialize MiFARE Ultralight C library instance with Ultralight C object returned by
            * NXP Semiconductor MiFARE SDK Library
            * */
            _MFUltralight_c_library = new MFUltralight_C_Library(ulC, getApplicationContext());

        }

        @Override
        public void onNTag203xCardDetected(INTag203x var1) {
                        /* Store current detected NFC tag type */
            _current_tag_type = TagType.NTag203x;

            /* Initialize MiFARE Ultralight C library instance with Ntag203x object returned by
            * NXP Semiconductor MiFARE SDK Library
            * */
            _NTag203x_library = new NTag203x_Library(var1, getApplicationContext());

            /* See if some write operation is waiting onNewIntent
            * If Write tag or bulk write tag pages are waiting for this NFC tap
            * then
            * Don't read.
            * */
        }

        @Override
        public void onNTag213215216CardDetected(INTag213215216 var1) {
            _current_tag_type = TagType.NTag213215216;

            _NTag213215216_library = new NTag213215216_Library(var1 , getApplicationContext());
        }

        @Override
        public void onNTagI2CCardDetected(INTagI2C var1) {
            _current_tag_type = TagType.NTAG_I2C;

            _NTagI2C_library = new NTagI2C_Library(var1, getApplicationContext());
        }

        @Override
        public void onNTagI2CplusCardDetected(INTAGI2Cplus var1) {
            _current_tag_type = TagType.NTAG_I2C_Plus;

            _NTagI2C_Plus_library = new NTagI2CPlus_Library(var1, getApplicationContext());

        }

//        /*
//        * NXP Semiconductor MiFARE SDK Library
//        * callback that handles NTAG203x type NFC tags
//        * */
//        @Override
//        public void onNTag203xCardDetected(final NTag203x nTag)
//        {
//            /* Store current detected NFC tag type */
//            _current_tag_type = TagType.NTag203x;
//
//            /* Initialize MiFARE Ultralight C library instance with Ntag203x object returned by
//            * NXP Semiconductor MiFARE SDK Library
//            * */
//            _NTag203x_library = new NTag203x_Library(nTag, getApplicationContext());
//
//            /* See if some write operation is waiting onNewIntent
//            * If Write tag or bulk write tag pages are waiting for this NFC tap
//            * then
//            * Don't read.
//            * */
//        }
//
//        @Override
//        public void  onNTag213215216CardDetected(final NTag213215216 object)
//        {
//            _current_tag_type = TagType.NTag213215216;
//
//            _NTag213215216_library = new NTag213215216_Library(object , getApplicationContext());
//        }
//
//        @Override
//        public void onNTagI2CCardDetected(NTagI2C var1) {
//            _current_tag_type = TagType.NTAG_I2C;
//            _NTagI2C_library = new NTagI2C_Library(var1 , getApplicationContext());
//        }
//
//        /////////////////////////////////
//        // Currently not supported types.
//        /////////////////////////////////
//        @Override
//        public void onUltraLightCardDetected(Ultralight var1) {
//            _current_tag_type = TagType.MFUltraLight;
//        }
//
//        @Override
//        public void onPlusSL1CardDetected(PlusSL1 var1) {
//            _current_tag_type = TagType.PlusSL1;
//        }
//
//        @Override
//        public void onUltraLightEV1CardDetected(UltralightEV1 var1) {
//            _current_tag_type = TagType.MFUltraLight_EV1;
//        }
//
//        @Override
//        public void onClassicCardDetected(MFClassic var1) {
//            _current_tag_type = TagType.MFClassic;
//        }
//
//        @Override
//        public void onPlusCardDetected(Plus var1) {
//            _current_tag_type = TagType.Plus;
//        }
//
//        @Override
//        public void onDESFireCardDetected(DESFire var1) {
//            _current_tag_type = TagType.DESFire;
//        }
//
//        @Override
//        public void onNTag210CardDetected(NTag210 var1) {
//            _current_tag_type = TagType.NTAG210;
//        }
//
//        @Override
//        public void onICodeSLIDetected(ICodeSLI var1)
//        {
//            _current_tag_type = TagType.ICODE_SLI;
//        }
//
//        @Override
//        public void onICodeSLISDetected(ICodeSLIS var1) {
//            _current_tag_type = TagType.ICODE_SLI_S;
//        }
//
//        @Override
//        public void onICodeSLILDetected(ICodeSLIL var1) {
//            _current_tag_type = TagType.ICode_SLI_L;
//        }
//
//        @Override
//        public void onICodeSLIXDetected(ICodeSLIX var1) {
//            _current_tag_type = TagType.ICODE_SLI_X_EV1;
//        }
//
//        @Override
//        public void onICodeSLIXSDetected(ICodeSLIXS var1) {
//            _current_tag_type = TagType.ICODE_SLI_XS_EV1;
//        }
//
//        @Override
//        public void onICodeSLIXLDetected(ICodeSLIXL var1) {
//            _current_tag_type = TagType.ICODE_SLI_XL_EV1;
//        }
//
//        @Override
//        public void onICodeSLIX2Detected(ICodeSLIX2 var1) {
//            _current_tag_type = TagType.ICODE_SLI_XS_EV1;
//        }
//
//        @Override
//        public void onNTag213F216FCardDetected(final NTag213F216F object) {
//            _current_tag_type = TagType.NTAG213F216F;
//        }
    };



    /**
     * Decides if new intent is to be used by Write Tag or Bulk Write page.
     * @return
     * true means main activity can continue NFC tag read.
     * false means main activity can not read as this intent was for write tag,overwrite or
     * bulk write page
     */
    private boolean nfc_intent_fragment_logic()
    {
        // Get the String ID of the fragment on top of the stack, initialize fragment variable to null
        // IASN-3 : Added bounds check to ensure no negative index
        String fragmentId = null;
        if (getFragmentManager().getBackStackEntryCount() > 0) {
            fragmentId = getFragmentManager().getBackStackEntryAt(getFragmentManager().getBackStackEntryCount() - 1).getName();
        }

        Fragment writeFragment = null;

        if (fragmentId != null) {
            // Find write tag fragment, if it is present in the Fragment Manager
            if (fragmentId.equals(FrameNames.write_tag_fragment_tag_string)) {
                writeFragment = getFragmentManager().findFragmentByTag(FrameNames.write_tag_fragment_tag_string);
            }

            if (fragmentId.equals(FrameNames.over_write_fragment_tag_string)) {
                writeFragment = getFragmentManager().findFragmentByTag(FrameNames.over_write_fragment_tag_string);
            }

            // Failing that, find the write beacon fragment if it is present in the Fragment Manager
            if (fragmentId.equals(FrameNames.beacon_write_page_fragment_string)) {
                writeFragment = getFragmentManager().findFragmentByTag(FrameNames.beacon_write_page_fragment_string);
            }

            //Failing THAT, find the beacon mode write fragment if it is present in the manager.
            if (fragmentId.equals(FrameNames.beacon_mode_fragment_string)) {
                writeFragment = getFragmentManager().findFragmentByTag(FrameNames.beacon_mode_fragment_string);
            }

        }

        // Use the read beacon dialog as the writeFragment if we are unlocking a beacon
        if (writeFragment == null && Unlocking_Beacon_Flag) {
            writeFragment = getFragmentManager().findFragmentByTag(FrameNames.beacon_read_page_fragment_string);
        }

        /* Find overwrite tag fragment*/
        OverWriteFragment overwriteFragment = (OverWriteFragment)getFragmentManager().findFragmentByTag(FrameNames.over_write_fragment_tag_string);

        /* Find bulk write fragment*/
        BulkWriteFragment bulkwriteFragment = (BulkWriteFragment) getFragmentManager().findFragmentByTag(FrameNames.Bulk_Write_fragment_tag_string);

        /* See if write tag/beacon fragment is present in stack*/
        if(writeFragment != null)
        {
            /* See if write tag fragment is visible*/
            if(writeFragment.isVisible()) {

                /* If write tag fragment is visible but writing dialog (appears when write
                 operation is pending on Write tag fragment) is null. In this case
                 just ignore the intent.
                 As user may be on the write tag page and editing fields
                 we don't want to interrupt him*/
                if(writing_dialog == null) {
                    return false;
                }


                /* If writing dialog is not visible.
                * Ignore intent. User may be editing fields*/
                if(!writing_dialog.isShowing()) {
                    return false;
                }
                else
                {
                    /* If write tag fragment is visible and writing dialog is also visible that means
                    * application is waiting for next NFC tag tap.
                    * we need to write data in this case*/
                    if (Ready_To_Write_Flag)
                    {
                        // Go Write
                        write_tag(mCurrentTagRecord, mLockTag);

                        // Clear read to write flag as we are done with pending write operation
                        Ready_To_Write_Flag = false;
                        // Clear this flag too, in case we are writing just the mode.
                        Mode_Write_Flag = false;
                        // Clear the Unlocking Beacon flag
                        Unlocking_Beacon_Flag = false;

                        // Job done. return.
                        return false;
                    }
                }
            }
        }

        /* See if overwrite fragment is present in stack*/
        if (overwriteFragment != null)
        {
            /* If over write tag fragment is visible. It means we have to ignore current intent*/
            if(overwriteFragment.isVisible())
                return false;
        }

        /* See if bulk write fragment is present in stack*/
        if (bulkwriteFragment != null)
        {
            /* See if write tag fragment is visible*/
            if(bulkwriteFragment.isVisible()) {

                /* If bulk write tag fragment is visible but writing dialog (appears when write
                 operation is pending on Write tag fragment) is null. In this case
                 just ignore the intent.
                 As user may be on the bulk write tag page
                 we don't want to interrupt him*/
                if(writing_dialog == null)
                    return false;

                /* If writing dialog is not visible.
                * Ignore intent.*/
                if(!writing_dialog.isShowing()) {
                    return false;
                }
                else
                {
                    // Go Write
                    /* We are not going to lock tags using bulk write operation */
                    boolean status = write_tag( mCurrentTagRecord, false);

                    //TagDataRecord dRecord = Bulk_Write_records.get(current_bulk_record_number);

                    //dRecord.setStatus(status);

                    updateBulkList_Fragment(current_bulk_record_id , status);

                    // Job done. return.
                    return false;
                }
            }
        }

        return true;
    }

    public  void updateBulkList_Fragment(int position, boolean status)
    {
        try {
         /* Find bulk write fragment*/
            BulkWriteFragment bulkwriteFragment = (BulkWriteFragment) getFragmentManager().findFragmentByTag(FrameNames.Bulk_Write_fragment_tag_string);

            if(bulkwriteFragment != null)
            {
                bulkwriteFragment.update_item(position, status);
            }
        }
        catch (Exception Ex)
        {

        }
    }

    /**
     * Starts Read tag fragment after read operation on New Intent.
     * @param _record contains user and site currently read from NFC tag
     */
    public  void startReadTag_Fragment(TagDataRecord _record)
    {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, ReadTagFragment.newInstance(_record) , FrameNames.read_tag_fragment_tag_string)
                .addToBackStack(FrameNames.read_tag_fragment_tag_string)
                .commit();
    }

    public  void startWriteTag_Fragment()
    {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, WriteTagFragment.newInstance(null, false) , FrameNames.write_tag_fragment_tag_string)
                .addToBackStack(FrameNames.write_tag_fragment_tag_string)
                .commit();
    }

    /* Display writing tag dialog containing
    * User and site fields*/
    public void display_writing_tag_dialog(TagDataRecord record, Boolean lock_tag) {
        mCurrentTagRecord = record;

        /* Store current lock state in activity. Will be used later while writing. */
        mLockTag = lock_tag;

        display_writing_dialog(record.getUser(), record.getSite(), record.getAccess());
    }


    public void display_writing_beacon_dialog(BeaconDataRecord record, Boolean lock_tag) {
        mCurrentTagRecord = record;
        mLockTag = lock_tag;

        display_writing_dialog("", record.getSite(), record.getAccess(), record.getRange(), record.getMode());
    }


    public void display_writing_beacon_dialog(BeaconDataRecord record, Boolean lock_tag, Boolean writing_mode) {
        mCurrentTagRecord = record;
        mLockTag = lock_tag;

        display_writing_dialog("", "", "", "", record.getMode());
    }


    public void display_writing_dialog(String user, String site, String accessLevel)
    {
        display_writing_dialog(user, site, accessLevel, "", "");
    }
    public void display_writing_dialog(String user, String site, String accessLevel, String range, String mode)
    {


        /*Initialize dialog*/
        writing_dialog = new Dialog(this);

        // Include dialog.xml file
        writing_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        writing_dialog.setContentView(R.layout.writetag_dialog);


        // Change user prompt if the item being written is a beacon
        if (mCurrentTagRecord instanceof BeaconDataRecord) {
            TextView writingDialogPrompt = (TextView) writing_dialog.findViewById(R.id.writing_dialog_prompt);
            ImageView writingDialogImage = (ImageView) writing_dialog.findViewById(R.id.writing_dialog_image);
            writingDialogPrompt.setText(getString(R.string.beacon_touch_prompt));
            writingDialogImage.setImageResource(R.drawable.ic_tap_beacon);
        }

        TextView writing_label = (TextView) writing_dialog.findViewById(R.id.writing_dialog_writing_label);

        if (mLockTag) {
            writing_label.setText(getString(R.string.writing_and_locking));
        }
        if (Unlocking_Beacon_Flag) {
            writing_label.setText(getString(R.string.unlocking_beacon));
        }


        /* Initialize user text view present in current dialog*/
        TextView dialog_user = (TextView) writing_dialog.findViewById(R.id.textview_writing_dialog_user);
        LinearLayout dialog_user_lay = (LinearLayout) writing_dialog.findViewById(R.id.layout_writing_dialog_user);

        if(user.equals(""))
        {
            dialog_user_lay.setVisibility(View.GONE);
        }
        else {
        /* Display current user string to be written*/
            dialog_user.setText(getString(R.string.User) + " : " + String.format("%1$-" + 16 + "s", user));
        }

        /* Initialize site text view present in current dialog*/
        TextView dialog_site = (TextView) writing_dialog.findViewById(R.id.textview_writing_dialog_site);
        LinearLayout dialog_site_lay = (LinearLayout) writing_dialog.findViewById(R.id.layout_writing_dialog_site);

        if(site.equals("")){
            dialog_site_lay.setVisibility(View.GONE);
        }
        else {
        /* Display current site string to be written*/
            dialog_site.setText(getString(R.string.Site) + " : " + site);
        }


        TextView dialog_range = (TextView) writing_dialog.findViewById(R.id.textview_writing_dialog_range);
        LinearLayout dialog_range_lay = (LinearLayout) writing_dialog.findViewById(R.id.layout_writing_dialog_range);

        if(range.equals("")) {
            dialog_range_lay.setVisibility(View.GONE);
        }
        else {
            // Try getting the string associated with this value. If not found (returns null), will display raw value.
            RangeLevel rl = RangeLevel.fromValue(range);
            if (rl != null) {
                range = rl.toString();
            }

            dialog_range.setText(getString(R.string.Range) + " : " + range);
        }


        TextView dialog_mode = (TextView) writing_dialog.findViewById(R.id.textview_writing_dialog_mode);
        LinearLayout dialog_mode_lay = (LinearLayout) writing_dialog.findViewById(R.id.layout_writing_dialog_mode);

        // If mode writing flag is false, hide this line. Otherwise display.
        if(!Mode_Write_Flag) {
            dialog_mode_lay.setVisibility(View.GONE);
        }
        else {
            // Try getting the mode associated with this value. If not found (returns null), will display raw value.
            BeaconMode bm = BeaconMode.fromValue(mode);
            if (bm != null) {
                mode = bm.toString();
            }
            dialog_mode.setText(getString(R.string.Mode) + " : " + mode);
        }


        TextView dialog_accessLevel = (TextView) writing_dialog.findViewById(R.id.textview_writing_dialog_accessLevel);
        LinearLayout dialog_accessLevel_lay = (LinearLayout) writing_dialog.findViewById(R.id.layout_writing_dialog_accessLevel);

        if(accessLevel.equals("")) {
            dialog_accessLevel_lay.setVisibility(View.GONE);
        }
        else {
            if (mCurrentTagRecord instanceof TagDataRecord) {
                UserAccessLevel al = UserAccessLevel.fromValue(accessLevel);
                if (al != null) {
                    accessLevel = al.toString();
                }
            }
            else {
                BeaconAccessLevel al = BeaconAccessLevel.fromValue(accessLevel);
                if (al != null) {
                    accessLevel = al.toString();
                }

            }
            dialog_accessLevel.setText(getString(R.string.Access) + " : " + accessLevel);
        }



        /* Display Dialog */
        writing_dialog.show();

        /* We need little more darker background than standard one to make dialog more prominent.
        * So, set dim amount to 0.8. (Maximum is 1)
        * */
        WindowManager.LayoutParams lp = writing_dialog.getWindow().getAttributes();
        lp.dimAmount = 0.8f;
        writing_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        writing_dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    public void dismiss_writing_dialog() {
        if (writing_dialog != null) {
            if (writing_dialog.isShowing()) {
                writing_dialog.dismiss();
            }
            writing_dialog = null;
        }
    }

    /**
     * Writes NFC tag by using appropriate library to accomplish the task
     * @param dataRecord NDef data inteface instance to write
     * @return
     * true - if write was successful
     * false - if write failed
     */
    public boolean write_tag(NDefDataRecord dataRecord, boolean lock_tag)
    {
        iError status;
        byte[] lockCode = new byte[4];

        String recordData = dataRecord.toNDefString();

        // If a beacon lock pin is registered, parse to byte array for writing
        if (mLockPIN != null) {
            lockCode = hashPinCode(mLockPIN);
        }

        try {

            /*Handle write tag operation with appropriate NFC tag library*/
            if (_current_tag_type == TagType.MiFareUltraLightC) {
            /* Call MiFARE ultra light c write NDEF record method*/
                status = _MFUltralight_c_library.Write_NDEF_Record(recordData, lock_tag);
            } else if (_current_tag_type == TagType.NTag203x) {
            /* Call NTag203x write NDEF Record method*/
                status = _NTag203x_library.Write_NDEF_Record(recordData, lock_tag);
            } else if (_current_tag_type == TagType.NTag213215216) {
                status = _NTag213215216_library.Write_NDEF_Record(recordData, lock_tag);
            } else if (_current_tag_type == TagType.NTAG_I2C) // Beacons use this library
            {
                // If unlocking flag true, unlock and do nothing else.
                if (Unlocking_Beacon_Flag) {
                    status = _NTagI2C_library.unlockBeacon();
                }
                // Write NDEF and lock beacon/tag if user clicked Lock
                else {
                    status = _NTagI2C_library.Write_NDEF_Record(recordData, lock_tag);
                    if (dataRecord instanceof BeaconDataRecord && lock_tag) {
                        _NTagI2C_library.lockBeacon(lockCode);
                    }
                    if (dataRecord instanceof TagDataRecord && lock_tag) {
                        _NTagI2C_library.lockTag();
                    }
                }

            } else if (_current_tag_type == TagType.NTAG_I2C_Plus) {
                status = _NTagI2C_Plus_library.Write_NDEF_Record(recordData, lock_tag);
            } else {
                writing_dialog.dismiss();
                writing_dialog = null;

                display_invalid_tag_dialog();

                return false;
            }
        }
        catch (Exception ex)
        {
            status = new iError(false, getString(R.string.communication_failed));
            Log.d(TAG, "NFC error: " + ex.getMessage());
        }
        /*Dismiss writing dialog as we are done with write operation*/
        writing_dialog.dismiss();
        writing_dialog = null;

        /* Display successful write dialog if write completed.
        * Display error write dialog if write failed*/
        if(status.getStatus()) {

            notify_user();

            Fragment readPage = getFragmentManager().findFragmentByTag(FrameNames.beacon_read_page_fragment_string);

            display_write_successful_dialog(dataRecord);

            // Display toast telling the user the beacon will lock in 15 seconds, then pop to beacon home or main home.
            if (mLockTag && dataRecord instanceof BeaconDataRecord) {
                Toast t = Toast.makeText(getApplicationContext(), getString(R.string.lock_in_15), Toast.LENGTH_LONG);
                t.show();
                getFragmentManager().popBackStack();
                if (readPage != null) {
                    getFragmentManager().popBackStack();
                }

            }

            // Display toast telling the user the beacon will unlock in 15 seconds, then pop the read page.
            if (Unlocking_Beacon_Flag) {
                Toast t = Toast.makeText(getApplicationContext(), getString(R.string.unlock_in_15), Toast.LENGTH_LONG);
                t.show();
                getFragmentManager().popBackStack();
            }

        }
        else
        {
            if (dataRecord instanceof BeaconDataRecord) {
                display_error_dialog(getString(R.string.Write_failed) , NextAction.Unknown, false);
            }
            else {
                display_error_dialog(getString(R.string.Write_failed) , NextAction.Unknown, true);
            }

        }

        return status.getStatus();
    }

    /**
     * Converts a 4-digit lock pin to a byte array for writing to beacon memory.
     * @param pin A 4-digit pin in the format of a string.
     * @return A byte array representing the pin provided.
     */
    private byte[] hashPinCode(String pin) {
        byte[] hashKey = new byte[] {(byte)0x00, (byte)0x04, (byte)0x01, (byte)0x02};
        byte[] result = new byte[4];
        for (int x = 0; x < 4; x++) {
            result[x] = (byte)Integer.parseInt(pin.substring(x, x+1), 16) ;
            result[x] = (byte) (result[x] ^ hashKey[x]);
        }

        return result;
    }

    /**
     * Displays write succesful dialog with current written user and site string.
     * @param record Ndef interface instance for success
     */
    private void display_write_successful_dialog(NDefDataRecord record)
    {
        // TODO: Get formatted success string from interface
        String user = "";
        String site = "";
        String range = "";
        String mode = "";
        String accessLevel = "";

        // Create custom dialog object
        write_success_dialog = new Dialog(this);

        // Include dialog.xml file
        write_success_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        write_success_dialog.setContentView(R.layout.writetag_success_dialog);


        // Get reference to the "Lock Successful" textview
        TextView lockStatusText = (TextView) write_success_dialog.findViewById(R.id.layout_unlock_success);
        ImageView successImage = (ImageView) write_success_dialog.findViewById(R.id.write_successful_image);

        if(record instanceof TagDataRecord) {
            TagDataRecord tagRecord = (TagDataRecord) record;
            user = tagRecord.getUser();
            site = tagRecord.getSite();
            accessLevel = tagRecord.getAccess();
            if (mLockTag) {
                lockStatusText.setText(getString(R.string.confirmation_tag_locked));
                lockStatusText.setVisibility(View.VISIBLE);
            }
        }

        if(record instanceof BeaconDataRecord) {
            BeaconDataRecord beaconRecord = (BeaconDataRecord) record;
            if (Mode_Write_Flag) {
                mode = beaconRecord.getMode();
            }
            else {
                site = beaconRecord.getSite();
                range = beaconRecord.getRange();
                accessLevel = beaconRecord.getAccess();
                if (mLockTag) {
                    lockStatusText.setText(getString(R.string.confirmation_beacon_locked));
                    lockStatusText.setVisibility(View.VISIBLE);
                }
            }

            // Set image displayed to beacon w/ checkmark
            if (successImage != null) {
                successImage.setImageResource(R.drawable.ic_beacon_success);
            }

        }



        /* Initialize user text view present in current dialog*/
        TextView dialog_user = (TextView) write_success_dialog.findViewById(R.id.textview_write_success_dialog_user);
        LinearLayout dialog_user_lay = (LinearLayout) write_success_dialog.findViewById(R.id.layout_write_success_dialog_user);

        if(user.equals(""))
        {
          dialog_user_lay.setVisibility(View.GONE);
        }
        else {
        /* Display user string written*/
            dialog_user.setText(getString(R.string.User) + " : " + String.format("%1$-" + 16 + "s", user));
        }

                /* Initialize site text view present in current dialog*/
        TextView dialog_site = (TextView) write_success_dialog.findViewById(R.id.textview_write_success_dialog_site);
        LinearLayout dialog_site_lay = (LinearLayout) write_success_dialog.findViewById(R.id.layout_write_success_dialog_site);

        if(site.equals(""))
        {
            dialog_site_lay.setVisibility(View.GONE);
        }
        else {
        /* Display site string written*/
            dialog_site.setText(getString(R.string.Site) + " : " + String.format("%1$-" + 16 + "s", site));
        }


        TextView dialog_range = (TextView) write_success_dialog.findViewById(R.id.textview_write_success_dialog_range);
        LinearLayout dialog_range_lay = (LinearLayout) write_success_dialog.findViewById(R.id.layout_write_success_dialog_range);

        if(range.equals(""))
        {
            dialog_range_lay.setVisibility(View.GONE);
        }
        else {
            // Try getting the string associated with this value. If not found (returns null), will display raw value.
            RangeLevel rl = RangeLevel.fromValue(range);
            if (rl != null) {
                range = rl.toString();
            }

            dialog_range.setText(getString(R.string.Range) + " : " + String.format("%1$-" + 16 + "s", range));
        }

        TextView dialog_mode = (TextView) write_success_dialog.findViewById(R.id.textview_write_success_dialog_mode);
        LinearLayout dialog_mode_lay = (LinearLayout) write_success_dialog.findViewById(R.id.layout_write_success_dialog_mode);

        // Do not show this element if mode is Normal
        if(mode.equals(""))
        {
            dialog_mode_lay.setVisibility(View.GONE);
        }
        else {
        // Try getting the mode associated with this value. If not found (returns null), will display raw value.
            BeaconMode bm = BeaconMode.fromValue(mode);
            if (bm != null) {
                mode = bm.toString();
            }

            dialog_mode.setText(getString(R.string.Mode) + " : " + String.format("%1$-" + 16 + "s", mode));
        }

        TextView dialog_accessLevel = (TextView) write_success_dialog.findViewById(R.id.textview_write_success_dialog_accessLevel);
        LinearLayout dialog_accessLevel_lay = (LinearLayout) write_success_dialog.findViewById(R.id.layout_write_success_dialog_accessLevel);

        if(accessLevel.equals(""))
        {
            dialog_accessLevel_lay.setVisibility(View.GONE);
        }
        else {
            if (mCurrentTagRecord instanceof TagDataRecord) {
                UserAccessLevel al = UserAccessLevel.fromValue(accessLevel);
                if (al != null) {
                    accessLevel = al.toString();
                }
            }
            else {
                BeaconAccessLevel al = BeaconAccessLevel.fromValue(accessLevel);
                if (al != null) {
                    accessLevel = al.toString();
                }

            }
            dialog_accessLevel.setText(getString(R.string.Access) + " : " + accessLevel);
        }


        if (Unlocking_Beacon_Flag) {
            TextView dialog_lock_success_text = (TextView) write_success_dialog.findViewById(R.id.layout_unlock_success);
            dialog_lock_success_text.setVisibility(View.VISIBLE);
        }


        /* Display Dialog*/
        write_success_dialog.show();

        /* We need little more darker background than standard one to make dialog more prominent.
        * So, set dim amount to 0.8. (Maximum is 1)
        * */
        WindowManager.LayoutParams lp = write_success_dialog.getWindow().getAttributes();
        lp.dimAmount = 0.8f;
        write_success_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        write_success_dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        /* For bulk write operation, we will start next write when current successful write dialog is dismissed*/
        write_success_dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                /*Go write next record for bulk tag write*/
                write_records();
            }
        });

        /* Automatically dismiss success after 2 milli seconds.*/
        final Timer t = new Timer();
        t.schedule(new TimerTask() {
            public void run() {
                write_success_dialog.dismiss(); // when the task active then close the dialog
                t.cancel(); // also just top the timer thread, otherwise, you may receive a crash report
            }
        }, 2000); // after 2 second (or 2000 mili seconds), the task will be active.
    }

    public void display_error_dialog(String message , final NextAction _next, boolean isTag)
    {
        // Create custom dialog object
        error_dialog = new Dialog(this);

        // Include dialog.xml file
        error_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        error_dialog.setContentView(R.layout.error_dialog);

        /* Initialize user textview/ imageview present in current dialog*/
        TextView dialog_message = (TextView) error_dialog.findViewById(R.id.textview_error_dialog);
        ImageView dialog_image = (ImageView) error_dialog.findViewById(R.id.imageview_error_dialog);

        /* Display user string written*/
        dialog_message.setText(message);

        // Change image if the error is related to beacon writing
        if (!isTag) {
            dialog_image.setImageResource(R.drawable.ic_invalidbeacon);
        }


        /* Display Dialog*/
        error_dialog.show();

        error_dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                /*Go write next record for bulk tag write*/
                if (_next == NextAction.Finish) {
                    // Kill activity
                    //finish();
                } else if (_next == NextAction.Write_Page) {
                    startWriteTag_Fragment();
                } else if (_next == NextAction.Enable_NFC) {
                    startActivity(new Intent(Settings.ACTION_NFC_SETTINGS));
                } else if (_next == NextAction.Unknown) {
                    if (read_dialog != null && read_dialog.isShowing()) {
                        read_dialog.dismiss();
                    }
                    read_dialog = null;
                    TagHomePageFragment tagDialogOwner = (TagHomePageFragment)getFragmentManager().findFragmentByTag(FrameNames.tag_home_fragment_tag_string);
                    if (tagDialogOwner != null) {
                        tagDialogOwner.dismiss_read_tag_dialog();
                    }
                    BeaconHomePageFragment beaconDialogOwner = (BeaconHomePageFragment)getFragmentManager().findFragmentByTag(FrameNames.beacon_home_page_fragment_string);
                    if (beaconDialogOwner != null) {
                        beaconDialogOwner.dismiss_read_beacon_dialog();
                    }
                } else {
                    // Forceful dismiss.

                    if (!mNfcAdapter.isEnabled()) {
                        startActivity(new Intent(Settings.ACTION_NFC_SETTINGS));
                    }
                }
            }
        });

        /* We need little more darker background than standard one to make dialog more prominent.
        * So, set dim amount to 0.8. (Maximum is 1)
        * */
        WindowManager.LayoutParams lp = error_dialog.getWindow().getAttributes();
        lp.dimAmount = 0.8f;
        error_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        error_dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        /* Automatically dismiss success after 2 milli seconds.*/
        final Timer t = new Timer();
        t.schedule(new TimerTask() {
            public void run() {
                error_dialog.dismiss(); // when the task active then close the dialog
                t.cancel(); // also just top the timer thread, otherwise, you may receive a crash report
            }
        }, 2000); // after 2 second (or 2000 mili seconds), the task will be active.
    }

    private void display_invalid_tag_dialog()
    {
        // Create custom dialog object
        invalid_tag_type_dialog = new Dialog(this);

        // Include dialog.xml file
        invalid_tag_type_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        invalid_tag_type_dialog.setContentView(R.layout.invalid_tag_dialog);

        /* Display Dialog*/
        invalid_tag_type_dialog.show();

        /* We need little more darker background than standard one to make dialog more prominent.
        * So, set dim amount to 0.8. (Maximum is 1)
        * */
        WindowManager.LayoutParams lp = invalid_tag_type_dialog.getWindow().getAttributes();
        lp.dimAmount = 0.8f;
        invalid_tag_type_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        invalid_tag_type_dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        /* Automatically dismiss success after 2 milli seconds.*/
        final Timer t = new Timer();
        t.schedule(new TimerTask() {
            public void run() {
                invalid_tag_type_dialog.dismiss(); // when the task active then close the dialog
                t.cancel(); // also just top the timer thread, otherwise, you may receive a crash report
            }
        }, 4000); // after 2 second (or 2000 mili seconds), the task will be active.
    }

    private void display_read_card_dialog()
    {
        read_dialog = new Dialog(this);
        read_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        read_dialog.setContentView(R.layout.readtag_dialog);

        TextView _touch_prompt = (TextView) read_dialog.findViewById(R.id.read_prompt_text);
        if (_touch_prompt != null) {
            _touch_prompt.setText(R.string.card_touch_prompt);
        }

        ImageView _prompt_image = (ImageView) read_dialog.findViewById(R.id.read_prompt_image);
        if (_prompt_image != null) {
            _prompt_image.setImageResource(R.drawable.ic_tap_card);
        }

        read_dialog.show();

        WindowManager.LayoutParams lp = read_dialog.getWindow().getAttributes();
        lp.dimAmount = 0.8f;
        read_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        read_dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

    }

    /**
     * Writes multiple data records, used by bulk write tag page
     */
    public void write_records()
    {
        /* Get next record from the list that needs to be written */
        TagDataRecord _record = get_next_record();

        /* If next record is null. Just get out.
        * We are done.*/
        if(_record == null)
            return;

        mCurrentTagRecord = _record;


        /*Display writing dialog with next record user and site string. Once user tap NFC tag, write process will happen.
        * From bulk write we will not lock tags
        * */
        display_writing_tag_dialog(_record, false);
    }

    /**
     * Gets next data record from list that is not written before.
     * @return
     * data record is returned if any found not written before.
     *  null is returned if not record is found or left to write
     */
    public TagDataRecord get_next_record()
    {
        total_bulk_records = Bulk_Write_records.size();

        for(int ind = 0; ind < Bulk_Write_records.size(); ind++)
        {
            /*Find any record that is not written before*/
            if(!Bulk_Write_records.get(ind).getStatus())
            {
                /* Set flag of currently selected record so that it should not be repeated during this write operation.
                * If current operation is aborted and user starts write again.
                * These flags will be cleared as list is re-populated again and tags will be written from start.
                * */
                Bulk_Write_records.get(ind).setStatus(true);

                current_bulk_record_id = Bulk_Write_records.get(ind).getPosition();

                /* return current available record that is not written before*/
                return Bulk_Write_records.get(ind);
            }

            current_bulk_record_number = ind+1;
        }

        /* no rag left or found in list*/
        return null;
    }

    /**
     * Used by each fragment to select appropriate item in navigation drawer.
     * @param position fragment option position in navigation drawer
     */
    public void select_page(int position)
    {
        mNavigationDrawerFragment.selectItem_no_callback(position);
    }

    public boolean getNFC_state()
    {
        if(mNfcAdapter != null) {
            return mNfcAdapter.isEnabled();
        }

        return false;
    }


    public void notify_user()
    {
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
            r.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void show_EULA()
    {
        eula_dialog = new Dialog(HomeActivity.this);

        // Include dialog.xml file
        eula_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        eula_dialog.setContentView(R.layout.end_user_license_dialog);
        eula_dialog.show();

        final TextView mAccept = (TextView) eula_dialog.findViewById(R.id.btn_accept_eula);
        mAccept.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP) {

                    mAccept.setBackgroundColor(getResources().getColor(R.color.indsci_orange));

                    SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(HomeActivity.this);
                    sp.edit().putBoolean(PREF_USER_ACCEPTED_EULA, true).apply();

                    eula_dialog.dismiss();
                }
                else if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    mAccept.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                }

                return  true;
            }
        });


        WindowManager.LayoutParams lp = eula_dialog.getWindow().getAttributes();
        lp.dimAmount = 0.8f;
        eula_dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        eula_dialog.setCanceledOnTouchOutside(false);
        eula_dialog.setCancelable(false);
    }



    public static void PushFragment(FragmentManager fragmentManager, android.app.Fragment fragmentInstance, String fragmentId) {


        fragmentManager.beginTransaction()
                .replace(R.id.container, fragmentInstance, fragmentId)
                .addToBackStack(fragmentId)
                .commit();
    }


    // Next 3 methods used for HockeyApp reporting
    private void checkForCrashes() {
        CrashManager.register(this);
    }

    private void checkForUpdates() {
        UpdateManager.register(this);
    }

    private void unregisterManagers() {
        UpdateManager.unregister();
    }

    @Override
    public void onStop ()
    {
        super.onStop();

        if(writing_dialog != null) {
            if (writing_dialog.isShowing()) {
                writing_dialog.dismiss();
                writing_dialog = null;
                Ready_To_Write_Flag = false;
                Mode_Write_Flag = false;
                Unlocking_Beacon_Flag = false;
                mLockTag = null;
            }
        }
        }

}
