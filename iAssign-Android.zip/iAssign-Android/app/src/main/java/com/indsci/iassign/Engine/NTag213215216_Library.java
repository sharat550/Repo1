package com.indsci.iassign.Engine;

import android.content.Context;

import com.indsci.iassign.Common.NdefRecord_Util;
import com.indsci.iassign.Common.iError;
import com.indsci.iassign.R;
import com.nxp.nfclib.exceptions.ReaderException;
import com.nxp.nfclib.exceptions.SmartCardException;
import com.nxp.nfclib.ndef.NdefMessageWrapper;
import com.nxp.nfclib.ntag.INTag213215216;
import java.io.IOException;
import java.util.Locale;

public class NTag213215216_Library {

    INTag213215216 objNTag213215216;

    Context context;

    /** Application Tag. */
    static final String TAG = "iAssign";

    public NTag213215216_Library()
    {

    }

    public NTag213215216_Library(INTag213215216 obj , Context _context)
    {
       objNTag213215216 = obj;

        context = _context;
    }

    public iError NTag213215216_Connect()
    {
        try
        {
           objNTag213215216.getReader().connect();
            return new iError(true, context.getString(R.string.connected));
        }
        catch (ReaderException cause)
        {
            cause.printStackTrace();
            return new iError(false, context.getString(R.string.connection_failed));
        }
    }

    public iError Write_NDEF_Record(String data, boolean lock_tag) {
        try {
            objNTag213215216.getReader().connect();

            if (!objNTag213215216.isT2T()) {
                // Format card for Forum Type 2.
                objNTag213215216.formatT2T();
            }


            NdefMessageWrapper msg = new NdefMessageWrapper(NdefRecord_Util.createTextRecord(data,
                    Locale.ENGLISH, true));

            // Write NDEF Message
            objNTag213215216.writeNDEF(msg);

            if(lock_tag)
            {
                objNTag213215216.makeCardReadOnly();
            }

            // Close connection
            objNTag213215216.getReader().close();
        }
        catch (ReaderException e) {
            //showMessage(e.getMessage());
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }
        catch (SmartCardException e) {
            //showMessage(e.getMessage());
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        } catch (IOException e) {
            //showMessage(Write_Failed);
            e.printStackTrace();
            return new iError(false, context.getString(R.string.communication_failed));
        }

        return new iError(true, context.getString(R.string.write_successful));
    }
}
