package com.indsci.iassign;

import android.app.FragmentManager;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.indsci.iassign.Common.TagDataRecord;
import com.indsci.iassign.Common.FrameNames;
import com.indsci.iassign.Common.UserAccessLevel;


public class ReadTagFragment extends Fragment
{
    private static final String User = "User";
    private static final String Site = "Site";
    private static final String Access = "Access";
    private static final String Locked = "Locked";

    Button btnEditTag;
    TextView eUser;
    TextView eSite;
    TextView eAccess;
    LinearLayout lockLinearLayout;

    String mUser;
    String mSite;
    String mAccess;
    Boolean mLocked;

    public static ReadTagFragment newInstance(TagDataRecord _record)
    {
        ReadTagFragment fragment = new ReadTagFragment();
        Bundle args = new Bundle();

        if(_record != null) {
            args.putString(User, _record.getUser());
            args.putString(Site, _record.getSite());
            args.putBoolean(Locked , _record.getLocked());
            args.putString(Access, _record.getAccess());
        }
        else
        {
            args.putString(User, "");
            args.putString(Site, "");
            args.putString(Access, "");
            args.putBoolean(Locked, false);
        }

        fragment.setArguments(args);
        return fragment;
    }

    public ReadTagFragment()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        if (getArguments() != null)
        {
            mUser = getArguments().getString(User);
            mSite = getArguments().getString(Site);
            mAccess = getArguments().getString(Access);
            mLocked = getArguments().getBoolean(Locked);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_read_tag, container, false);

        eUser = (TextView) v.findViewById(R.id.readtag_edit_user);
        eUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWriteTag_Fragment();
            }
        });

        eSite = (TextView) v.findViewById(R.id.readtag_edit_site);
        eSite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWriteTag_Fragment();
            }
        });

        eAccess = (TextView) v.findViewById(R.id.readtag_access_level);
        eAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWriteTag_Fragment();
            }
        });

        lockLinearLayout = (LinearLayout) v.findViewById(R.id.readtag_locked_layout);

        btnEditTag = (Button) v.findViewById(R.id.btn_readtag_edit_button);

        btnEditTag.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    btnEditTag.setBackground(getResources().getDrawable(R.drawable.button_back));

                    // Send the field data to Write Tag Fragment.
                    startWriteTag_Fragment();
                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btnEditTag.setBackgroundColor(getResources().getColor(R.color.indsci_orange_shade));
                }

                return true;
            }
        });

        if(mUser != null)
        {
            eUser.setText(mUser);
        }
        else
        {
            eUser.setText("");
        }

        if(mSite != null)
        {
            eSite.setText(mSite);
        }
        else
        {
            eSite.setText("");
        }

        if (mAccess != null) {
            UserAccessLevel _access = UserAccessLevel.fromValue(mAccess);
            eAccess.setText(_access != null  ?  _access.toString()  :  mAccess);
        }

        if(!mLocked)
        {
            lockLinearLayout.setVisibility(View.GONE);
            btnEditTag.setEnabled(true);
        }
        else
        {
            lockLinearLayout.setVisibility(View.VISIBLE);
            btnEditTag.setEnabled(false);
        }

        select_navigation_option();

        return  v;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
        super.onSaveInstanceState(savedInstanceState);

        if(eUser == null)
            return;

        if(eSite == null)
            return;

        if (eAccess == null){
            return;
        }


        savedInstanceState.putString(User, eUser.getText().toString());
        savedInstanceState.putString(Site, eSite.getText().toString());
        savedInstanceState.putString(Access, eAccess.getText().toString());
        savedInstanceState.putBoolean(Locked, mLocked);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (savedInstanceState != null) {
            String user = savedInstanceState.getString(User);
            eUser.setText(user);

            String site = savedInstanceState.getString(Site);
            eSite.setText(site);

            eAccess.setText(savedInstanceState.getString(Access));

            Boolean locked = savedInstanceState.getBoolean(Locked);

            if(!locked)
            {
                lockLinearLayout.setVisibility(View.GONE);
                btnEditTag.setEnabled(true);
            }
            else
            {
                lockLinearLayout.setVisibility(View.VISIBLE);
                btnEditTag.setEnabled(false);
            }

        }
    }

    public  void startWriteTag_Fragment()
    {
        //get User field.
        String field_user = eUser.getText().toString();

        // get Site field.
        String field_site = eSite.getText().toString();

        // Create new tag record, passing through access level value from read
        TagDataRecord dRecord = new TagDataRecord(field_user, field_site , mAccess, false, false ,0);

        // update the main content by replacing fragments
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, WriteTagFragment.newInstance(dRecord , false) , FrameNames.write_tag_fragment_tag_string)
                .addToBackStack(FrameNames.write_tag_fragment_tag_string)
                .commit();
    }

    private void select_navigation_option()
    {
        HomeActivity hActivity = (HomeActivity) getActivity();

        if(hActivity != null) {
            hActivity.select_page(1);
        }
    }
}
