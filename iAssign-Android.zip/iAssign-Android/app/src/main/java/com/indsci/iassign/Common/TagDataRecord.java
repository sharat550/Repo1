package com.indsci.iassign.Common;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

public class TagDataRecord implements NDefDataRecord
{
    String User;
    String Site;
    String Access;
    boolean Status;
    boolean Locked;
    int position;

    iError _iError;

    public TagDataRecord()
    {

    }

    public TagDataRecord(String _user, String _site , String _access, boolean _status, boolean islocked , int pos)
    {
        User = _user;
        Site = _site;
        Access = _access;
        Status = _status;
        Locked = islocked;
        _iError = null;
        position = pos;
    }

    public TagDataRecord(iError error)
    {
        User  = "";
        Site = "";
        Status = false;
        Locked = false;
        _iError = error;
        position = -1;
    }

    public String getUser()
    {
        return User;
    }

    public void setUser(String user)
    {
        User = user;
    }

    public String getSite()
    {
        return Site;
    }

    public void setSite(String site)
    {
        Site = site;
    }

    public void setStatus(boolean status)
    {
        Status = status;
    }

    public String getAccess() { return Access; }

    public boolean getStatus()
    {
        return Status;
    }

    public void setAccess(String access) { Access = access; }

    public boolean getLocked()
    {
        return Locked;
    }

    public void setLocked(boolean locked)
    {
        Locked = locked;
    }

    public void set_iError(iError _iErr)
    {
        _iError = _iErr;
    }

    public iError get_iError()
    {
        return _iError;
    }

    public int getPosition()
    {
        return position;
    }
    public void setPosition(int pos)
    {
        position = pos;
    }

    public static TagDataRecord FromNDefFields(List<String> fields, boolean is_locked) {

        TagDataRecord record = new TagDataRecord("","","", false , is_locked, 0);

        try {
            for (String field : fields) {
                // IASN-10: Need to check for valid fields (presence of : char) in case of spurious data as well as an empty value
                if(field.contains(":")) {
                    String[] kvp = field.split(":");
                    if(kvp.length == 2) { // IASN-10
                        switch (kvp[0]) {
                            case "User":
                                record.setUser(kvp[1]);
                                break;
                            case "Site":
                                record.setSite(kvp[1]);
                                break;
                            case "Access":
                                record.setAccess(kvp[1]);
                                break;

                        }
                    }
                }
            }
        } catch(Exception e) {
            return null;
        }
        return record;

//        // Record consisting of all three fields
//        if(fields.size() >= 3)
//        {
//            // First field will always be considered as user.
//            String user_prefixed = fields.get(0);
//            // Second field will always be considered as site.
//            String site_prefixed = fields.get(1);
//            // Third field should be the access level.
//            String access_prefixed = fields.get(2);
//
//            // Never translate following string.
//            if(user_prefixed.contains("User:"))
//            {
//                user_prefixed = user_prefixed.substring(5);
//            }
//
//            record.setUser(user_prefixed);
//
//            // Never translate following string.
//            if(site_prefixed.contains("Site:"))
//            {
//                site_prefixed = site_prefixed.substring(5);
//            }
//
//            record.setSite(site_prefixed);
//
//            //Trim the NDEF prefix from the string
//            if(access_prefixed.contains("Access:")) {
//                access_prefixed = access_prefixed.substring(7);
//            }
//
//            record.setAccess(access_prefixed);
//
//
//            return record;
//        }
//
//        // Will be a combination User OR Site, plus Access
//        else if(fields.size() == 2)
//        {
//            // Determine if the field is a User or Site
//            String field_prefixed = fields.get(0);
//
//            // Never translate following string.
//            if(field_prefixed.contains("User:"))
//            {
//                field_prefixed = field_prefixed.substring(5);
//                record.setUser(field_prefixed);
//            }
//
//            // Never translate following string.
//            else if(field_prefixed.contains("Site:"))
//            {
//                field_prefixed = field_prefixed.substring(5);
//                record.setSite(field_prefixed);
//            }
//
//            // Invalid record
//            else
//            {
//                return null;
//            }
//
//            // Process Access field
//            String access_prefixed = fields.get(1);
//
//            if (access_prefixed.contains("Access:")) {
//                access_prefixed = access_prefixed.substring(7);
//            }
//            record.setAccess(access_prefixed);
//
//            // Return processed record
//            return record;
//        }
//        else
//        {
//            // If could not parse or record consists of Access only,
//            return null;
//        }
    }

    public String toNDefString() {
        List<String> fields = new ArrayList<String>();

        if (User.length() >= 1) {
            fields.add("User:" + User);
        }

        if (Site.length() >= 1) {
            fields.add("Site:" + Site);
        }

        // IASN-10: Only writing Access field if an access level was chosen
        if(Access.length() >= 1) {
            fields.add("Access:" + Access);
        }
        String ndefResult = TextUtils.join("#", fields) + "#";

        // IASN-9: Writing fewer padding characters as it was exceeding 44 bytes (UTF-8)
        for (int i = 0; i < (19 - ( User.length() + Site.length() + Access.length() )); i++) {
            ndefResult = ndefResult + (char)0x00;
        }
        return ndefResult;
    }

}

