package com.indsci.iassign.Common;

import com.indsci.iassign.R;
import java.util.ArrayList;

/**
 * Created by JAgostoni on 7/12/2016.
 */
public enum BeaconMode {
    Normal("A", R.string.beacon_mode_normal),
    Sleep("S", R.string.beacon_mode_sleep),
    DFU("U", R.string.beacon_mode_dfu);

    private String mode;
    private int id;

    BeaconMode(String beaconMode, int resourceId) {
        mode = beaconMode;
        id = resourceId;
    }


    @Override
    public String toString()
    {
        return IAssignApplication.getContext().getString(id);
    }

    public static BeaconMode fromString(String val) {
        for (BeaconMode v: values()) {
            if (v.toString().equals(val)) {
                return v;
            }
        }
        return null;
    }

    public static ArrayList<String> toIdList() {
        ArrayList<String> _modeValues = new ArrayList<>();
        for (BeaconMode bm : BeaconMode.values()) {
            _modeValues.add(bm.toString());
        }
        return _modeValues;
    }

    public String toValue() { return mode; }

    public static BeaconMode fromValue(String mode) {
        for (BeaconMode v: values()) {
            if(v.mode.equals(mode)) {
                return v;
            }
        }

        return null;
    }


}
