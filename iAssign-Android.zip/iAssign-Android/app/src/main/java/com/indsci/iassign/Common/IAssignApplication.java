package com.indsci.iassign.Common;

import android.app.Application;
import android.content.Context;

/**
 * Created by JAgostoni on 7/12/2016.
 */
public class IAssignApplication extends Application {

    private static Context mContext;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = getApplicationContext();
    }

    public static Context getContext() {
        return mContext;
    }
}
