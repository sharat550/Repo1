package com.indsci.iassign;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.LinearLayout;
import com.indsci.iassign.Beacons.BeaconHomePageFragment;
import com.indsci.iassign.Common.FrameNames;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomePageFragment extends Fragment {


    LinearLayout _BeaconManagementButton;
    LinearLayout _TagManagementButton;
    LinearLayout _BuyIassignButton;


    public HomePageFragment() {
        // Required empty public constructor
    }


    public static HomePageFragment newInstance()
    {
        HomePageFragment fragment = new HomePageFragment();


        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View inflated = inflater.inflate(R.layout.fragment_home_page, container, false);

        _BeaconManagementButton = (LinearLayout) inflated.findViewById(R.id.btn_home_beacon_management);
        _BeaconManagementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HomeActivity.PushFragment(getFragmentManager(), BeaconHomePageFragment.newInstance(), FrameNames.beacon_home_page_fragment_string);
            }
        });

        _TagManagementButton = (LinearLayout) inflated.findViewById(R.id.btn_home_tag_management);
        _TagManagementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HomeActivity.PushFragment(getFragmentManager(), TagHomePageFragment.newInstance(false), FrameNames.tag_home_fragment_tag_string);
            }
        });

        _BuyIassignButton = (LinearLayout) inflated.findViewById(R.id.btn_buy_iassign);
        _BuyIassignButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                HomeActivity.PushFragment(getFragmentManager(), BuyIassignFragment.newInstance(), FrameNames.buy_iassign_fragment_string);
            }
        });

        return inflated;
    }

}
