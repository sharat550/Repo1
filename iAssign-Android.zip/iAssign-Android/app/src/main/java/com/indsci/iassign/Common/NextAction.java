package com.indsci.iassign.Common;

public enum NextAction {
    Finish,
    Write_Page,
    Enable_NFC,
    Unknown,
}
