package com.indsci.iassign;

import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

/**
 * Fragment used for managing interactions for and presentation of a navigation drawer.
 * See the <a href="https://developer.android.com/design/patterns/navigation-drawer.html#Interaction">
 * design guidelines</a> for a complete explanation of the behaviors implemented here.
 */
public class NavigationDrawerFragment extends Fragment {

    LinearLayout l_home_button;
    LinearLayout l_read_tag_button;
    LinearLayout l_write_tag_button;
    LinearLayout l_buy_iassign_button;
    LinearLayout l_Bulk_Write_button;
    LinearLayout l_about_button;
    LinearLayout l_legal_button;
    LinearLayout l_feedback_button;
    LinearLayout l_language_button;
    LinearLayout l_help_button;

    LinearLayout _TagHomeLayout;
    LinearLayout _BeaconHomeLayout;
    LinearLayout _CardHomeLayout;


    /**
     * Remember the position of the selected item.
     */
    private static final String STATE_SELECTED_POSITION = "selected_navigation_drawer_position";

    /**
     * Per the design guidelines, you should show the drawer on launch until the user manually
     * expands it. This shared preference tracks this.
     */
    private static final String PREF_USER_LEARNED_DRAWER = "navigation_drawer_learned";
    private static final String PREF_USER_Prefered_Language = "iAssignLanguage";

    /**
     * A pointer to the current callbacks instance (the Activity).
     */
    private NavigationDrawerCallbacks mCallbacks;

    /**
     * Helper component that ties the action bar to the navigation drawer.
     */
    private ActionBarDrawerToggle mDrawerToggle;

    private DrawerLayout mDrawerLayout;
    private ListView mDrawerListView;
    private View mFragmentContainerView;

    private int mCurrentSelectedPosition = 0;
    private boolean mFromSavedInstanceState;
    private boolean mUserLearnedDrawer;

    private int mDrawerSize = 240;

    public NavigationDrawerFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Read in the flag indicating whether or not the user has demonstrated awareness of the
        // drawer. See PREF_USER_LEARNED_DRAWER for details.
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
        mUserLearnedDrawer = sp.getBoolean(PREF_USER_LEARNED_DRAWER, false);

        if (savedInstanceState != null) {
            mCurrentSelectedPosition = savedInstanceState.getInt(STATE_SELECTED_POSITION);
            mFromSavedInstanceState = true;
        }
        else {
            // Select either the default item (0) or the last selected item.
            selectItem(mCurrentSelectedPosition);
        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // Indicate that this fragment would like to influence the set of actions in the action bar.
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View V = inflater.inflate(R.layout.fragment_navigation_drawer, container, false);

        // update the main content by replacing fragments
//        final FragmentManager fragmentManager = getActivity().getFragmentManager();
//        final String TAG_FRAGMENT = "From_Nav_Drawer";

        l_home_button = (LinearLayout) V.findViewById(R.id.layout_home_button);
        l_home_button.setClickable(true);
        l_home_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(0);
            }
        });


        _BeaconHomeLayout = (LinearLayout) V.findViewById(R.id.layout_beacon_home_button);
        _BeaconHomeLayout.setClickable(true);
        _BeaconHomeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectItem(10);
            }
        });

        _TagHomeLayout = (LinearLayout) V.findViewById(R.id.layout_tag_home_button);
        _TagHomeLayout.setClickable(true);
        _TagHomeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectItem(11);
            }
        });

        _CardHomeLayout = (LinearLayout) V.findViewById(R.id.layout_cards_home_button);
        _CardHomeLayout.setClickable(true);
        _CardHomeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectItem(12);
            }
        });


//        l_read_tag_button = (LinearLayout) V.findViewById(R.id.layout_read_tag_button);
//        l_read_tag_button.setClickable(true);
//        l_read_tag_button.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View v)
//            {
//                selectItem(1);
//            }
//        });

//        l_write_tag_button = (LinearLayout) V.findViewById(R.id.layout_write_tag_buttton);
//        l_write_tag_button.setClickable(true);
//        l_write_tag_button.setOnClickListener(new View.OnClickListener()
//        {
//            @Override
//            public void onClick(View v)
//            {
//                selectItem(2);
//            }
//        });

        l_buy_iassign_button = (LinearLayout) V.findViewById(R.id.layout_buy_iassign_button);
        l_buy_iassign_button.setClickable(true);
        l_buy_iassign_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(3);
            }
        });

        l_Bulk_Write_button = (LinearLayout) V.findViewById(R.id.layout_Bulk_Write_button);
        l_Bulk_Write_button.setClickable(true);
        l_Bulk_Write_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(4);
            }
        });

        l_about_button = (LinearLayout) V.findViewById(R.id.layout_about_button);
        l_about_button.setClickable(true);
        l_about_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(5);
            }
        });


        l_legal_button = (LinearLayout) V.findViewById(R.id.layout_legal_button);
        l_legal_button.setClickable(true);
        l_legal_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(6);
            }
        });


        l_language_button = (LinearLayout) V.findViewById(R.id.language_button);
        l_language_button.setClickable(true);
        l_language_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(7);
            }
        });


        l_feedback_button = (LinearLayout) V.findViewById(R.id.layout_feedback_button);
        l_feedback_button.setClickable(true);
        l_feedback_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(8);
            }
        });

        l_help_button = (LinearLayout) V.findViewById(R.id.layout_help_button);
        l_help_button.setClickable(true);
        l_help_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                selectItem(9);
            }
        });

        //mDrawerListView.setItemChecked(mCurrentSelectedPosition, true);

        return V;
    }

    public boolean isDrawerOpen() {
        return mDrawerLayout != null && mDrawerLayout.isDrawerOpen(mFragmentContainerView);
    }

    /**
     * Users of this fragment must call this method to set up the navigation drawer interactions.
     *
     * @param fragmentId   The android:id of this fragment in its activity's layout.
     * @param drawerLayout The DrawerLayout containing this fragment's UI.
     */
    public void setUp(int fragmentId, DrawerLayout drawerLayout) {
        mFragmentContainerView = getActivity().findViewById(fragmentId);
        mDrawerLayout = drawerLayout;

        // set a custom shadow that overlays the main content when the drawer opens
        mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);
        // set up the drawer's list view with items and click listener

        ActionBar actionBar = getActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        //actionBar.setCustomView(R.layout.title_bar_layout);
        //actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setHomeButtonEnabled(true);

        // ActionBarDrawerToggle ties together the the proper interactions
        // between the navigation drawer and the action bar app icon.
        mDrawerToggle = new ActionBarDrawerToggle(
                getActivity(),                    /* host Activity */
                mDrawerLayout,                    /* DrawerLayout object */
//                R.drawable.ic_drawer,             /* nav drawer image to replace 'Up' caret */
                R.string.navigation_drawer_open,  /* "open drawer" description for accessibility */
                R.string.navigation_drawer_close  /* "close drawer" description for accessibility */
        ) {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                if (!isAdded()) {
                    return;
                }

                getActivity().supportInvalidateOptionsMenu(); // calls onPrepareOptionsMenu()
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                if (!isAdded()) {
                    return;
                }

                if (!mUserLearnedDrawer) {
                    // The user manually opened the drawer; store this flag to prevent auto-showing
                    // the navigation drawer automatically in the future.
                    mUserLearnedDrawer = true;
                    SharedPreferences sp = PreferenceManager
                            .getDefaultSharedPreferences(getActivity());
                    sp.edit().putBoolean(PREF_USER_LEARNED_DRAWER, true).apply();
                }

                getActivity().supportInvalidateOptionsMenu(); // calls onPrepareOptionsMenu()
            }
        };


        // If the user hasn't 'learned' about the drawer, open it to introduce them to the drawer,
        // per the navigation drawer design guidelines.
        if (!mUserLearnedDrawer && !mFromSavedInstanceState) {
            mDrawerLayout.openDrawer(mFragmentContainerView);
        }

        // Defer code dependent on restoration of previous instance state.
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });

        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    private void selectItem(int position) {
        mCurrentSelectedPosition = position;

        if(mDrawerLayout != null)
        {
            clearBackgrounds();
            setBackgrounds(position);
        }

        if (mDrawerListView != null) {
            mDrawerListView.setItemChecked(position, true);
        }
        if (mDrawerLayout != null) {
            mDrawerLayout.closeDrawer(mFragmentContainerView);
        }
        if (mCallbacks != null) {
            mCallbacks.onNavigationDrawerItemSelected(position);
        }
    }

    public void selectItem_no_callback(int position)
    {
        mCurrentSelectedPosition = position;

        if(mDrawerLayout != null)
        {
            clearBackgrounds();
            setBackgrounds(position);
        }

        if (mDrawerListView != null) {
            mDrawerListView.setItemChecked(position, true);
        }
        if (mDrawerLayout != null) {
            mDrawerLayout.closeDrawer(mFragmentContainerView);
        }
    }


    private void clearBackgrounds()
    {
        int color = getResources().getColor(R.color.indsci_white);

        l_home_button.setBackgroundColor(color);
//        l_read_tag_button.setBackgroundColor(color);
//        l_write_tag_button.setBackgroundColor(color);
        l_buy_iassign_button.setBackgroundColor(color);
        l_Bulk_Write_button.setBackgroundColor(color);
        l_about_button.setBackgroundColor(color);
        l_language_button.setBackgroundColor(color);
        l_feedback_button.setBackgroundColor(color);
        l_legal_button.setBackgroundColor(color);
        l_help_button.setBackgroundColor(color);

        _BeaconHomeLayout.setBackgroundColor(color);
        _CardHomeLayout.setBackgroundColor(color);
        _TagHomeLayout.setBackgroundColor(color);
    }

    private void setBackgrounds(int position)
    {
        int color = getResources().getColor(R.color.indsci_grayed);
        switch (position)
        {
            case 0:
                l_home_button.setBackgroundColor(color);
                break;
            case 1:
//                l_read_tag_button.setBackgroundColor(color);
                break;
            case 2:
//                l_write_tag_button.setBackgroundColor(color);
                break;
            case 3:
                l_buy_iassign_button.setBackgroundColor(color);
                break;
            case 4:
                l_Bulk_Write_button.setBackgroundColor(color);
                break;
            case 5:
                l_about_button.setBackgroundColor(color);
                break;
            case 6:
                l_legal_button.setBackgroundColor(color);
                break;
            case 7:
                l_language_button.setBackgroundColor(color);
                break;
            case 8:
                l_feedback_button.setBackgroundColor(color);
                break;
            case 9:
                l_help_button.setBackgroundColor(color);
                break;
            case 10:
                _BeaconHomeLayout.setBackgroundColor(color);
                break;
            case 11:
                _TagHomeLayout.setBackgroundColor(color);
                break;
            case 12:
                _CardHomeLayout.setBackgroundColor(color);
                break;

        }

    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCallbacks = (NavigationDrawerCallbacks) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException("Activity must implement NavigationDrawerCallbacks.");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SELECTED_POSITION, mCurrentSelectedPosition);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Forward the new configuration the drawer toggle component.
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // If the drawer is open, show the global app actions in the action bar. See also
        // showGlobalContextActionBar, which controls the top-left area of the action bar.
        if (mDrawerLayout != null && isDrawerOpen()) {
            inflater.inflate(R.menu.global, menu);
            showGlobalContextActionBar();
        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        return mDrawerToggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }

    /**
     * Per the navigation drawer design guidelines, updates the action bar to show the global app
     * 'context', rather than just what's in the current screen.
     */
    private void showGlobalContextActionBar() {
//        ActionBar actionBar = getActionBar();
//        actionBar.setDisplayShowTitleEnabled(true);
//        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
//        actionBar.setTitle(R.string.app_name);
    }

    private ActionBar getActionBar() {
        return ((ActionBarActivity) getActivity()).getSupportActionBar();
    }

    /**
     * Callbacks interface that all activities using this fragment must implement.
     */
    public interface NavigationDrawerCallbacks {
        /**
         * Called when an item in the navigation drawer is selected.
         */
        void onNavigationDrawerItemSelected(int position);
    }


//    // Navigation Drawer
//    public class ObjectDrawerItem {
//
//        public int icon;
//        public String name;
//        public int left_padding;
//
//        // Constructor.
//        public ObjectDrawerItem(int icon, String name, int left_padding) {
//
//            this.icon = icon;
//            this.name = name;
//            this.left_padding = left_padding;
//        }
//    }

    // Navigation Menu Drawer
//    public class DrawerItemCustomAdapter extends ArrayAdapter<ObjectDrawerItem> {
//
//        Context mContext;
//        int layoutResourceId;
//        ObjectDrawerItem data[] = null;
//
//
//        public DrawerItemCustomAdapter(Context mContext, int layoutResourceId, ObjectDrawerItem[] data) {
//
//            super(mContext, layoutResourceId, data);
//            this.layoutResourceId = layoutResourceId;
//            this.mContext = mContext;
//            this.data = data;
//        }
//
//        @Override
//        public View getView(int position, View convertView, ViewGroup parent) {
//
//            View listItem = convertView;
//
//            LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
//            listItem = inflater.inflate(layoutResourceId, parent, false);
//
//            ImageView imageViewIcon = (ImageView) listItem.findViewById(R.id.imageViewIcon);
//            TextView textViewName = (TextView) listItem.findViewById(R.id.textViewName);
//
//            ObjectDrawerItem folder = data[position];
//
//
//            imageViewIcon.setImageResource(folder.icon);
//            imageViewIcon.setPadding(folder.left_padding,0,0,0);
//            textViewName.setText(folder.name);
//
//            return listItem;
//        }
//
//    }
}
